"""
File : add_event_to_queue.py
Description : This module adds events as JSON data to a queue.
Created on : 20-March-2025
Author :
E-mail :
"""

import json
import datetime
import logging
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.exceptions.base_exception import RabbitMQServiceMessagingServiceManagerException
from src.python.app.common.rabbitmq_messaging_service import RabbitMQService
from src.python.app.utils.logger import LoggingConfig

logger = LoggingConfig().setup_logging() 

class AddEventToQueue:

    @staticmethod
    def add_event_to_queue(event_generated_data, no_of_frames_in_ei, frames_range, timestamp_last_frame_in_ei, 
                             email_sent_status, notification_on_milestone_status, evidence_video_on_nas):
        """
        Adds event data as JSON to the queue for further processing.
        Raises:
            SchemaValidationException: If any error occurs during the process.
        """
        event_queue_name="event_queue"
        try:
            event_data = {
                "camera_asset_id": event_generated_data.get(constant.CAMERA_ASSET_ID),
                "event_time": str(event_generated_data.get(constant.EVENT_TIME)),
                "usecase_id": event_generated_data.get(constant.USECASE_ID),
                "event_data": str(event_generated_data.get(constant.EVENT_DATA)),
                "location_id": event_generated_data.get(constant.META_LOCATION_ID),
                "evidence_storage_path": event_generated_data.get(constant.EVIDENCE_STORAGE_PATH),
                "is_evidence_sent_on_nas": evidence_video_on_nas,
                "notification_on_milestone_status": notification_on_milestone_status,
                "number_of_frames": no_of_frames_in_ei,
                "frames_range": frames_range,
                "created_date_time": str(datetime.datetime.now()),
                "decode_timestamp": str(datetime.datetime.strptime(timestamp_last_frame_in_ei, '%Y-%m-%dT%H:%M:%S.%f')),
                "is_email_sent": email_sent_status,
                "request_status": event_generated_data.get(constant.REQUEST_STATUS)
            }

            # Convert to JSON and send to queue
            
            RabbitMQService().send_message(event_queue_name,event_data)

            logger.info("Event added to queue successfully")
            return True
        
        except Exception as e:
            logger.error(f"Error adding event to queue: {e}")
            raise RabbitMQServiceMessagingServiceManagerException(f"add_event_to_queue --> Exception occurred: {e}") from e
