"""
File        : config_alert_consumer.py
Description : WebSocket server that listens for messages and triggers a dynamic
              configuration reload from the database upon receiving messages.
Created on  : 2025-06-18
Author      : HCLTech
"""
import json
import uvicorn
import threading
import time
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.websockets import WebSocketState
from src.python.app.common.dynamic_config_updater import DynamicConfigUpdater
from src.python.app.utils.logger import LoggingConfig

logger = LoggingConfig().setup_logging()
app = FastAPI()

hit_counter = {"/config_update": 0}

class ConnectionManager:
    def __init__(self):
        self.active_connections = set()

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        logger.info(f"New connection. Total: {len(self.active_connections)}")
        self.active_connections.add(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            logger.info(f"Disconnected. Remaining: {len(self.active_connections)}")

    async def send_personal_message(self, message: str, websocket: WebSocket):
        if websocket.client_state == WebSocketState.CONNECTED:
            try:
                await websocket.send_text(message)
            except Exception as e:
                logger.info(f"Error sending message: {e}")
                self.disconnect(websocket)

    async def broadcast(self, message: str, sender: WebSocket = None):
        disconnected = set()
        for connection in self.active_connections:
            if connection != sender:
                try:
                    if connection.client_state == WebSocketState.CONNECTED:
                        await connection.send_text(message)
                    else:
                        disconnected.add(connection)
                except Exception as e:
                    logger.info(f"Broadcast error: {e}")
                    disconnected.add(connection)
        for connection in disconnected:
            self.disconnect(connection)

manager = ConnectionManager()

@app.get("/health")
async def health_check():
    return {"status": "ok", "websocket_hits": hit_counter.get("/config_update", 0)}

@app.websocket("/config_update")
async def websocket_endpoint(websocket: WebSocket):
    hit_counter["/config_update"] += 1
    logger.info(f"/config_update endpoint hit count: {hit_counter['/config_update']}")
    
    await manager.connect(websocket)
    try:
        while True:
            raw_data = await websocket.receive_text()
            logger.info(f"Received message from {websocket.client.host}: {raw_data}")

            try:
                data = json.loads(raw_data)
            except json.JSONDecodeError:
                logger.error("Invalid JSON received")
                await manager.send_personal_message("Invalid JSON format", websocket)
                continue

            if data.get("Updated_event_manager_config") is True:
                try:
                    DynamicConfigUpdater.update_global_config()
                    await manager.send_personal_message(
                        "Configuration updated successfully.", websocket
                    )
                    logger.info("Configuration updated from WebSocket trigger.")
                except Exception as e:
                    logger.error(f"Error during config update: {e}")
                    await manager.send_personal_message(
                        f"Error updating configuration: {e}", websocket
                    )
            else:
                logger.warning("Message received but no config update triggered.")
                await manager.send_personal_message(
                    "No valid config update instruction found.", websocket
                )

    except WebSocketDisconnect:
        manager.disconnect(websocket)
        logger.info("WebSocket client disconnected.")
    except Exception as e:
        manager.disconnect(websocket)
        logger.error(f"Unexpected error in WebSocket loop: {e}")


def start_uvicorn():
    try:
        logger.info("FastAPI WebSocket server starting on ws://0.0.0.0:9015")
        uvicorn.run(app, host="0.0.0.0", port=9015, log_level="info")
    except Exception as e:
        logger.error(f"Uvicorn crashed with exception: {e}")


# Monitoring and Retry Thread Logic
server_thread = None

def start_config_updater_ws_server():
    global server_thread

    def monitor_and_restart():
        global server_thread
        while True:
            if server_thread is None or not server_thread.is_alive():
                logger.warning("WebSocket server thread is not alive. Restarting...")
                server_thread = threading.Thread(target=start_uvicorn, name="ConfigUpdaterServer")
                server_thread.start()
                time.sleep(5)
            else:
                logger.info(f"WebSocket server thread '{server_thread.name}' is alive.")
            time.sleep(3600) 

    monitor_thread = threading.Thread(target = monitor_and_restart, name="WSMonitor", daemon=True)
    monitor_thread.start()
