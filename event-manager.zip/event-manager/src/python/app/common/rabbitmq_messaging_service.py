"""
File: rabbitmq_service.py
Description: RabbitMQ service for batch message send/receive with improved error handling.
Created on: 2025-05-27
Author: 
E-mail:

"""

import logging
import pika
import json
import time
from pika.exceptions import StreamLostError, ConnectionClosed, AMQPError
from src.python.app.constant.global_data import GlobalData
from src.python.app.constant.project_constant import Constant
from src.python.app.utils.logger import LoggingConfig
from src.python.app.common.config_manager import cfg

logger = LoggingConfig().setup_logging()


class RabbitMQService:
    """
    RabbitMQ Service to manage sending and receiving messages in batch with robust connection handling.
    """
    
    def __init__(self):
        logging.getLogger("pika").setLevel(logging.WARNING)
        self.rabbitmq_host = cfg.get_environment_config(Constant.RABBITMQ_HOST)
        self.rabbitmq_port = int(cfg.get_environment_config(Constant.RABBITMQ_PORT))
        username = cfg.get_environment_config(Constant.RABBITMQ_USERNAME)
        password = cfg.get_environment_config(Constant.RABBITMQ_PASSWORD)
        self.credentials = pika.PlainCredentials(username, password)
        self.connection = None
        self.channel = None
        self.exchange_name = "carrix_exchange"

        self.last_receive_error_log_time = 0
        self.error_log_interval = 15 * 60  

    def connect(self, retries=3, delay=10):
        for attempt in range(retries):
            try:
                self.connection = pika.BlockingConnection(
                    pika.ConnectionParameters(
                        host=self.rabbitmq_host,
                        port=self.rabbitmq_port,
                        credentials=self.credentials,
                        heartbeat=600,
                        blocked_connection_timeout=300,
                        socket_timeout=10,
                        connection_attempts=3,
                        retry_delay=5
                    )
                )
                self.channel = self.connection.channel()
                self.channel.exchange_declare(exchange=self.exchange_name, exchange_type='direct', durable = True)
                logger.info("Connected to RabbitMQ and declared exchange successfully!")
                return Constant.SUCCESS_STATUS
            except Exception as e:
                logger.error(f"Failed to connect to RabbitMQ (Attempt {attempt + 1}/{retries}): {repr(e)}")
                if attempt < retries - 1:
                    time.sleep(delay)
                else:
                    logger.error("Max retries reached. Could not establish connection.")
                    return Constant.FAILURE_STATUS

    def ensure_connection(self):
        """
        Ensures the RabbitMQ connection and channel are open, reconnects if needed.
        """
        if self.connection is None or self.connection.is_closed:
            self.connect()
        elif self.channel is None or self.channel.is_closed:
            self.channel = self.connection.channel()


    def receive_messages_batch(self, queue_name, max_messages=5):
        """
        Receive a batch of messages from a given RabbitMQ queue.

        Parameters:
            queue_name (str): Name of the queue to read messages from.
            max_messages (int): Maximum number of messages to fetch.

        Returns:
            list: A list of decoded messages.
        """
        messages = []
        try:
            self.ensure_connection()

            for _ in range(max_messages):
                method_frame, _, body = self.channel.basic_get(queue=queue_name, auto_ack=True)
                if method_frame is None:
                    break
                if body is None:
                    logger.warning("Received message with no body. Skipping.")
                    continue
                try:
                    message = json.loads(body.decode("utf-8"))
                    messages.append(message)
                except json.JSONDecodeError as je:
                    logger.warning(f"Skipping malformed message: {je}")
                    continue

        except (ConnectionClosed, AMQPError) as e:
            logger.warning(f"Connection issue during receive: Returning empty list.")
            return []

        except StreamLostError as sle:
            logger.warning(f"Stream lost while receiving messages: Skipping retry.")
            return []

        except Exception as e:
            now = time.time()
            if now - self.last_receive_error_log_time > self.error_log_interval:
                self.last_receive_error_log_time = now
            return []

        return messages
    
    