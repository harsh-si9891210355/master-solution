"""
File        : websocket_event_notifier.py
Description : This module sends real-time event notifications using WebSockets synchronously.
              It starts a WebSocket server to communicate with connected clients and 
              broadcasts event data to all active connections.
Created on  : 27-March-2025
Author      : HCLTech
"""

import time
import json
import websocket
from threading import Thread
from websocket_server import WebsocketServer
from src.python.app.utils.logger import LoggingConfig
from src.python.app.common.config_manager import cfg
from src.python.app.constant.project_constant import Constant

logger = LoggingConfig().setup_logging()

clients = list()


class WebSocketEventNotifier:
    """
    Class to handle real-time event notifications via WebSockets.
    
    Attributes:
        server (WebsocketServer): Static reference to the WebSocket server instance.
    """

    server = None

    @staticmethod
    def send_event(event_id, event_generated_data, no_of_frames_in_ei, frames_range,
                   timestamp_last_frame_in_ei, email_sent_status,
                   notification_on_milestone_status, evidence_video_on_nas, event_manager_end_time, event_uid):
        """
        Sends structured event data to all connected WebSocket clients.

        Args:
            event_id (str): Unique identifier for the event.
            event_generated_data (dict): Dictionary containing metadata and payload of the event.
            no_of_frames_in_ei (int): Number of frames in the Event Instance.
            frames_range (str): Range of frames involved in the event.
            timestamp_last_frame_in_ei (str): Timestamp of the last frame in the Event Instance.
            email_sent_status (bool): Flag indicating whether an email was sent.
            notification_on_milestone_status (bool): Flag for milestone notification status.
            evidence_video_on_nas (bool): Flag for whether video evidence is stored on NAS.

        Returns:
            bool: True if message dispatch attempted.
        """
        event_data = {
            "event_id": event_id,
            "event_uid":event_uid,
            "camera_asset_id": event_generated_data.get(Constant.CAMERA_ASSET_ID),
            "event_time": event_generated_data.get(Constant.EVENT_TIME),
            "usecase_id": event_generated_data.get(Constant.USECASE_ID),
            "event_data": event_generated_data.get(Constant.EVENT_DATA),
            "location_id": event_generated_data.get(Constant.META_LOCATION_ID),
            "evidence_storage_path": event_generated_data.get(Constant.EVIDENCE_STORAGE_PATH),
            "is_evidence_sent_on_nas": evidence_video_on_nas,
            "notification_on_milestone_status": notification_on_milestone_status,
            "number_of_frames": no_of_frames_in_ei,
            "frames_range": frames_range,
            "decode_timestamp": timestamp_last_frame_in_ei,
            "is_email_sent": email_sent_status,
            "request_status": event_generated_data.get(Constant.REQUEST_STATUS),
            "event_manager_end_time": event_manager_end_time
        }

        message = json.dumps(event_data)
        logger.info(f"Sending WebSocket event: {message}")

        for client in clients:
            try:
                WebSocketEventNotifier.server.send_message(client, message)
            except Exception as e:
                logger.info(f"[SERVER] Error sending message to client {client}: {e}")

        return True

    @staticmethod
    def start_websocket_server():
        """
        Starts the WebSocket server in a background thread.

        This method initializes a WebSocket server that listens for incoming client connections,
        handles disconnections, and receives messages. Each client is tracked in a shared list.
        The server runs on the configured host and port as defined in the environment config.
        
        Note:
            - The server runs in a separate daemon thread and does not block the main process.
            - All client connection events are logged.
        """

        def run_server():
            def new_client(client, server):
                logger.info(f"[SERVER] New client connected: {client}")
                clients.append(client)

            def client_left(client, server):
                logger.info(f"[SERVER] Client disconnected: {client}")
                if client in clients:
                    clients.remove(client)

            def message_received(client, server, message):
                logger.info(f"[SERVER] Received message from client {client['id']}: {message}")

            server = WebsocketServer(
                port=int(cfg.get_environment_config(Constant.CONFIG_WEBSOCKET_PORT)),
                host=str(cfg.get_environment_config(Constant.CONFIG_WEBSOCKET_HOST))
            )
            server.set_fn_new_client(new_client)
            server.set_fn_client_left(client_left)
            server.set_fn_message_received(message_received)

            WebSocketEventNotifier.server = server

            logger.info(
                f"[SERVER] WebSocket server started on "
                f"ws://{cfg.get_environment_config(Constant.CONFIG_WEBSOCKET_HOST)}:"
                f"{cfg.get_environment_config(Constant.CONFIG_WEBSOCKET_PORT)}"
            )
            server.run_forever()

        server_thread = Thread(target=run_server, daemon=True)
        server_thread.start()
