"""
File : event_generation_handler.py
Description : Handles Event generation analysis.
Created on : 10-Feb-2025
Author : HCLTech
E-mail :
"""

import cv2
import os
import subprocess
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.exceptions.base_exception import EventGenerationHandlerError
from src.python.app.utils.logger import LoggingConfig
from src.python.app.utils.image_conversion import img_util
from src.python.app.common.config_manager import cfg

logger = LoggingConfig().setup_logging()


class EventGenerationHandler:
    """
    Handles Event Generation.
    """

    def analyse_event(self, all_detections, camera_asset_id, usecase_name):
        """
        Collect frames for a given camera and use case to create both raw and processed video evidences.

        Args:
            all_detections: List of detection tuples, expected format [(timestamp, ..., raw_frame, processed_frame, ...), ...]
            camera_asset_id: Identifier for the camera asset.
            usecase_name: Use case name for the event.

        Returns:
            A tuple containing:
                - List of event info [usecase_name, camera_asset_id].
                - Path to temporary raw video file.
                - Path to final raw evidence video file.
                - Path to temporary processed video file.
                - Path to final processed evidence video file.

            Returns empty list and Nones if no frames to process.
        """
        try:
            evidence_videos_folder = cfg.get_resource_config(constant.CONFIG_EVIDENCE_VIDEOS_PATH)
            os.makedirs(evidence_videos_folder, exist_ok=True)

            start_ts = all_detections[0][1]
            end_ts = all_detections[-1][1]
            base_filename = f"evidence_{camera_asset_id}_{start_ts}_{end_ts}_{usecase_name}"

            # Paths
            raw_tmp_path = os.path.join(evidence_videos_folder, f"{base_filename}_raw_tmp.mp4")
            processed_tmp_path = os.path.join(evidence_videos_folder, f"{base_filename}_processed_tmp.mp4")

            evidence_video_folder = evidence_videos_folder.replace('/evidence', '/video_evidence')
            os.makedirs(evidence_video_folder, exist_ok=True)
            raw_final_path = os.path.join(evidence_video_folder, f"{base_filename}_raw_final.mp4")
            processed_final_path = os.path.join(evidence_video_folder, f"{base_filename}_processed_final.mp4")

            video_width = int(cfg.get_environment_config(constant.CONFIG_EVIDENCE_VIDEO_WIDTH))
            video_height = int(cfg.get_environment_config(constant.CONFIG_EVIDENCE_VIDEO_HEIGHT))
            size = (video_width, video_height)

            raw_frames, processed_frames = [], []

            for frame_data in all_detections:
                _, _,_, processed_frame_data,raw_frame_data,_ = frame_data

                try:
                    raw_img = img_util.convert_to_image(raw_frame_data)
                    proc_img = img_util.convert_to_image(processed_frame_data)

                    if raw_img is not None:
                        raw_frames.append(raw_img)
                    if proc_img is not None:
                        processed_frames.append(proc_img)
                except Exception as decode_err:
                    logger.error(f"Error decoding frames: {decode_err}")

            if not raw_frames and not processed_frames:
                logger.warning("No valid frames collected for video generation.")
                return [], None, None, None, None

            # Write helper
            def write_video(frames, path):
                codec = cv2.VideoWriter_fourcc(*'mp4v')
                writer = cv2.VideoWriter(path, codec, 1, size)
                if not writer.isOpened():
                    raise EventGenerationHandlerError(f"Failed to initialize VideoWriter for {path}")
                for f in frames:
                    if f.shape[1] != video_width or f.shape[0] != video_height:
                        f = cv2.resize(f, size)
                    writer.write(f)
                writer.release()

            # Write both videos
            if raw_frames:
                write_video(raw_frames, raw_tmp_path)
            if processed_frames:
                write_video(processed_frames, processed_tmp_path)

            # FFmpeg helper
            def convert_video(input_path, output_path):
                ffmpeg_cmd = [
                    'ffmpeg', '-y',
                    '-i', input_path,
                    '-vcodec', 'libx264',
                    '-preset', 'medium',
                    '-crf', '20',
                    '-pix_fmt', 'yuv420p',
                    output_path
                ]
                subprocess.run(ffmpeg_cmd, check=True)
                logger.info(f"[EVENT] Converted video created at {output_path}")

            if raw_frames:
                convert_video(raw_tmp_path, raw_final_path)
            if processed_frames:
                convert_video(processed_tmp_path, processed_final_path)

            final_event_data = [[usecase_name, camera_asset_id]]
            return final_event_data, raw_tmp_path, raw_final_path, processed_tmp_path, processed_final_path

        except Exception as e:
            logger.error(f"Error in analyse_event: {e}")
            raise EventGenerationHandlerError(f"Cannot analyse event: {e}")


    def prepare_event_data(
        self,
        camera_id,
        location_id,
        camera_asset_id,
        object_name,
        detection,
        event_time,
        evidence_url,
        cluster,
        usecase_id,
        request_status
    ):
        """
        Prepare and format sensor event response data.

        Args:
            camera_id: Camera identifier.
            location_id: Location identifier.
            camera_asset_id: Camera asset identifier.
            object_name: Name of the detected object/event.
            detection: Percentage of obstruction detected.
            event_time: Timestamp of the event.
            evidence_url: URL/path to the evidence video or image.
            cluster: Cluster index for detection categorization.
            usecase_id: Usecase identifier.
            request_status: Status of the event request.

        Returns:
            dict: Formatted event data dictionary.

        Raises:
            EventGenerationHandlerError: If data preparation fails.
        """
        try:
            event_data = {
                constant.CAMERA_ID: camera_id,
                constant.CAMERA_ASSET_ID: camera_asset_id,
                constant.SENSOR_EVENT_TIME: event_time,
                constant.USECASE_ID: usecase_id,
                constant.SENSOR_EVENT_TYPE: object_name,
                constant.EVIDENCE_STORAGE_PATH: evidence_url,
                constant.REQUEST_STATUS: request_status,
                constant.META_LOCATION_ID: location_id,
                constant.SENSOR_EVENT_DATA: constant.DETECTION_DICT.get(cluster, None)
            }
            return event_data

        except Exception as e:
            logger.error(f"Error in prepare_event_data: {e}")
            raise EventGenerationHandlerError(f"Unable to prepare event data: {e}")
        

    def analyse_event_of_leaving_work_zone(self,
                  processed_frames_list,     # list of 10 processed frames (bytes)
                  start_ts,                 # start timestamp
                  end_ts,                   # end timestamp
                  camera_asset_id,          # camera id
                  usecase_name):            # usecase name
        """
        processed_frames_list: 
            [ processed_frame_bytes_1, processed_frame_bytes_2, ... ]
        """

        try:
            # ------------------------- Folder Setup -------------------------
            evidence_videos_folder = cfg.get_resource_config(constant.CONFIG_EVIDENCE_VIDEOS_PATH)
            os.makedirs(evidence_videos_folder, exist_ok=True)

            final_evidence_folder = evidence_videos_folder.replace("/evidence", "/video_evidence")
            os.makedirs(final_evidence_folder, exist_ok=True)

            # ------------------------- Filenames -----------------------------
            base_filename = f"evidence_{camera_asset_id}_{start_ts}_{end_ts}_{usecase_name}"

            processed_tmp_path = os.path.join(evidence_videos_folder, f"{base_filename}_processed_tmp.mp4")
            processed_final_path = os.path.join(final_evidence_folder, f"{base_filename}_processed_final.mp4")

            # ------------------------- Video Settings ------------------------
            video_width = int(cfg.get_environment_config(constant.CONFIG_EVIDENCE_VIDEO_WIDTH))
            video_height = int(cfg.get_environment_config(constant.CONFIG_EVIDENCE_VIDEO_HEIGHT))
            size = (video_width, video_height)

            # ------------------------- Decode Frames -------------------------
            processed_frames = []

            for img in processed_frames_list:
                try:
                    if img is not None:
                        if img.shape[1] != video_width or img.shape[0] != video_height:
                            img = cv2.resize(img, size)
                        processed_frames.append(img)
                except Exception as err:
                    logger.error(f"Error decoding processed frame: {err}")

            if not processed_frames:
                logger.warning("No processed frames available.")
                return [], None, None

            # ------------------------- Write Temp Video -----------------------
            codec = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(processed_tmp_path, codec, 1, size)

            if not writer.isOpened():
                raise EventGenerationHandlerError(f"Failed VideoWriter for {processed_tmp_path}")

            for frame in processed_frames:
                writer.write(frame)

            writer.release()

            # ------------------------- FFmpeg Conversion ----------------------
            ffmpeg_cmd = [
                "ffmpeg", "-y",
                "-i", processed_tmp_path,
                "-vcodec", "libx264",
                "-preset", "medium",
                "-crf", "20",
                "-pix_fmt", "yuv420p",
                processed_final_path
            ]

            subprocess.run(ffmpeg_cmd, check=True)

            # ------------------------- Return Values -------------------------
            event_info = [[usecase_name, camera_asset_id]]

            return event_info, processed_tmp_path, processed_final_path

        except Exception as e:
            logger.error(f"Error in analyse_event: {e}")
            raise EventGenerationHandlerError(f"Cannot analyse event: {e}")

    def create_single_camera_video(self, frames, camera_name, start_ts, end_ts, usecase_name):
        """
        Creates a video from a list of frames (base64 or images) for a single camera.
        """
        try:
            evidence_videos_folder = cfg.get_resource_config(constant.CONFIG_EVIDENCE_VIDEOS_PATH)
            os.makedirs(evidence_videos_folder, exist_ok=True)
            
            final_evidence_folder = evidence_videos_folder.replace("/evidence", "/video_evidence")
            os.makedirs(final_evidence_folder, exist_ok=True)
            
            base_filename = f"evidence_{camera_name}_{start_ts}_{end_ts}_{usecase_name}_single"
            tmp_path = os.path.join(evidence_videos_folder, f"{base_filename}_tmp.mp4")
            final_path = os.path.join(final_evidence_folder, f"{base_filename}.mp4")
            
            video_width = int(cfg.get_environment_config(constant.CONFIG_EVIDENCE_VIDEO_WIDTH))
            video_height = int(cfg.get_environment_config(constant.CONFIG_EVIDENCE_VIDEO_HEIGHT))
            size = (video_width, video_height)
            
            decoded_frames = []
            for frame in frames:
                try:
                    if frame is None:
                        continue
                    
                    if isinstance(frame, (str, bytes)):
                        img = img_util.convert_to_image(frame)
                    else:
                        img = frame
                        
                    if img is not None:
                        if img.shape[1] != video_width or img.shape[0] != video_height:
                            img = cv2.resize(img, size)
                        decoded_frames.append(img)
                except Exception as e:
                    logger.error(f"Error decoding frame for single camera video: {e}")
            
            if not decoded_frames:
                logger.warning(f"No valid frames for camera {camera_name}")
                return None
            
            # Write temp video
            codec = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(tmp_path, codec, 1, size)
            if not writer.isOpened():
                raise EventGenerationHandlerError(f"Failed VideoWriter for {tmp_path}")
            
            for f in decoded_frames:
                writer.write(f)
            writer.release()
            
            # Convert with ffmpeg
            ffmpeg_cmd = [
                "ffmpeg", "-y",
                "-i", tmp_path,
                "-vcodec", "libx264",
                "-preset", "medium",
                "-crf", "20",
                "-pix_fmt", "yuv420p",
                final_path
            ]
            subprocess.run(ffmpeg_cmd, check=True)
            
            # Remove tmp
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
                
            return final_path
            
        except Exception as e:
            logger.error(f"Error in create_single_camera_video: {e}")
            return None
