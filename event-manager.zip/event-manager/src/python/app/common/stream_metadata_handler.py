"""
File : stream_metadata_handler.py
Description : This will handle metadata from stream and process them with stream
Created on : 17-Feb-2025
Author :
E-mail :
"""

import json

from src.python.app.common.config_manager import cfg
from src.python.app.constant.project_constant import Constant
from src.python.app.constant.global_data import GlobalData
from src.python.app.exceptions.base_exception import FileNotFoundException,SensorMetadataHandlerException, MetaDataGetAttributeError

class StreamMetaDataHandler():
    """
    
    
    """
    def __init__(self):
        self.template_loaded = Constant.FAILURE_STATUS
    
    def read_metadata_template(self):
        """read_metadata_template function is responsible to read metadata
                and to process it.
        """
        try:
            metadata_template_file_path = str(Constant.PROJECT_ROOT_DIR)+str(cfg.get_resource_config(Constant.CONFIG_RESOURCES_METADATA_TEMPLATE_FILE))
        except Exception as e:
            raise SensorMetadataHandlerException("Metadata File not found : {0}".format(e))
        try:
            with open(metadata_template_file_path) as f:
                json_template = json.load(f)
        except Exception as e:
            raise SensorMetadataHandlerException("Json file not loaded : {0}".format(e))
        finally:
            f.close()
        GlobalData.sensor_metadata = json_template
        self.template_loaded = Constant.SUCCESS_STATUS
        return self.template_loaded
            
    def get_single_attribute_value(self, attribute_name):
        """
        Get a single attribute in the metadata message variable
        """
        try:
            data_template = GlobalData.sensor_metadata
            if attribute_name == Constant.META_SENSOR_ID:
                return data_template[Constant.META_SENSOR_ID]
            else:
                for meta_value in data_template[Constant.META_FRAME_METADATA]:
                    if meta_value == attribute_name:
                        value = data_template[Constant.META_FRAME_METADATA].get(meta_value)
                        return value
            return None
        except Exception as e:
            raise MetaDataGetAttributeError("Exception occour {0} in fetching Metadata attribute ".format(e)) from e

     
