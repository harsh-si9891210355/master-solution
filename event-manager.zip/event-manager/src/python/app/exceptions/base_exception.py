"""
File : base_exception.py
Description : Class is responsible for custom exception handling in the stream handling module
Created on : 17-Feb-2025
Author : HCLTech
E-mail :
"""

from src.python.app.utils.logger import LoggingConfig

logger = LoggingConfig().setup_logging()
        


class EventManagerException(Exception):
    """
    This class is responsible for custom exception handling in the stream handling module
    """

    message = ''

    def __init__(self, message):
        self.message = message
        logger.error(self.message)

    def __str__(self):
        return repr(self.message)


class FileNotFoundException(EventManagerException):
    def __init__(self, message):
        super(FileNotFoundException, self).__init__(message)


class StreamProcessingException(EventManagerException):
    def __init__(self, message):
        super(StreamProcessingException, self).__init__(message)
        

class ConnectionError(EventManagerException):
    def __init__(self, message):
        super(ConnectionError,self).__init__(message)

class MetaDataUpdationError(EventManagerException):
    def __init__(self, message):
        super(MetaDataUpdationError,self).__init__(message)

class AzureMessagingServiceManagerException(EventManagerException):
    def __init__(self, message):
        super(AzureMessagingServiceManagerException,self).__init__(message)

class SensorInitiationException(EventManagerException):
    def __init__(self, message):
        super(SensorInitiationException,self).__init__(message)

class SensorProcessingHandlerException(EventManagerException):
    def __init__(self, message):
        super(SensorProcessingHandlerException,self).__init__(message)

class DatabaseConnectorException(EventManagerException):
    def __init__(self, message):
        super(DatabaseConnectorException,self).__init__(message)
        

class DatabaseConnectionException(EventManagerException):
    def __init__(self, message):
        super(DatabaseConnectionException,self).__init__(message)
        

class SensorMetadataHandlerException(EventManagerException):
    def __init__(self, message):
        super(SensorMetadataHandlerException,self).__init__(message)

class ClusterListEmptyException(EventManagerException):
    def __init__(self, message):
        super(ClusterListEmptyException,self).__init__(message)
        
        
class SchemaValidationException(EventManagerException):
    def __init__(self, message):
        super(SchemaValidationException,self).__init__(message)
        
class ImageConversionException(EventManagerException):
    def __init__(self, message):
        super(ImageConversionException,self).__init__(message)
        
class EventGenerationHandlerError(EventManagerException):
    def __init__(self, message):
        super(EventGenerationHandlerError,self).__init__(message)

class EventProcessingHandlerException(EventManagerException):
    def __init__(self, message):
        super(EventProcessingHandlerException,self).__init__(message)
        

class MetaDataGetAttributeError(EventManagerException):
    def __init__(self, message):
        super(MetaDataGetAttributeError,self).__init__(message)

class RabbitMQServiceMessagingServiceManagerException(EventManagerException):
    def __init__(self, message):
        super(RabbitMQServiceMessagingServiceManagerException,self).__init__(message)     
        

class EventGenerationHandlerError(EventManagerException):
    def __init__(self, message):
        super(EventGenerationHandlerError,self).__init__(message)     
        

class DetectionHandlerError(EventManagerException):
    def __init__(self, message):
        super(DetectionHandlerError,self).__init__(message)     
               
        
        
          
        

        
