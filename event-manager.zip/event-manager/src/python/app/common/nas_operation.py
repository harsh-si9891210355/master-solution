
import shutil
import os

class NASFileManager:
    def __init__(self, nas_path="/nas_share"):
        self.nas_path = nas_path

    def list_files(self):
        """List files in the NAS directory."""
        try:
            files = os.listdir(self.nas_path)
            print("Files on NAS:", files)
            return files
        except Exception as e:
            print(f"Error listing files: {e}")

    def upload_file(self, local_path):
        """Copy file from container to NAS."""
        try:
            shutil.copy(local_path, self.nas_path)
            print(f"Uploaded {local_path} to NAS.")
        except Exception as e:
            print(f"Upload error: {e}")

    def download_file(self, file_name, local_path):
        """Copy file from NAS to container."""
        try:
            shutil.copy(os.path.join(self.nas_path, file_name), local_path)
            print(f"Downloaded {file_name} to {local_path}.")
        except Exception as e:
            print(f"Download error: {e}")

    def delete_file(self, file_name):
        """Delete file from NAS."""
        try:
            os.remove(os.path.join(self.nas_path, file_name))
            print(f"Deleted {file_name} from NAS.")
        except Exception as e:
            print(f"Delete error: {e}")

if __name__ == "__main__":
    nas = NASFileManager()
    
    while True:
        print("\n--- NAS File Operations Menu ---")
        print("1. List Files")
        print("2. Upload File")
        print("3. Download File")
        print("4. Delete File")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            nas.list_files()
        elif choice == "2":
            local_path = input("Enter the path of the file to upload: ")
            nas.upload_file(local_path)
        elif choice == "3":
            file_name = input("Enter file name to download: ")
            local_path = input("Enter the download path: ")
            nas.download_file(file_name, local_path)
        elif choice == "4":
            file_name = input("Enter the file name to delete: ")
            nas.delete_file(file_name)
        elif choice == "5":
            print("Exiting...")
            break
        else:
            print("Invalid choice, please try again.")
