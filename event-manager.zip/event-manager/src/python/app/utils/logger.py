"""
File : logger.py
Description : Class is responsible for logging info and errors
Created on : 17-Feb-2025
Author : HCLTech
Includes:
- Daily rotating file handlers with custom retention.
- Console logging for real-time log streaming.
- Custom filters for log level segregation.
- Dynamic log file naming based on retention days.
"""

import os
import logging
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo  

debug_log_flag = os.getenv("ENABLE_LOG_DEBUG", "false").lower() == "true"
error_log_flag = os.getenv("ENABLE_LOG_ERROR", "true").lower() == "true"
critical_log_flag = os.getenv("ENABLE_LOG_CRITICAL", "true").lower() == "true"
info_log_level = os.getenv("ENABLE_LOG_INFO", "true").lower() == "true"
warning_log_level = os.getenv("ENABLE_LOG_WARNING", "true").lower() == "true"
retention_days = int(os.getenv("LOG_RETENTION_DAYS", "1"))

# Timezone for logging
mexico_zone = ZoneInfo("America/Mexico_City")

class MexicoFormatter(logging.Formatter):
    def converter(self, timestamp):
        return datetime.fromtimestamp(timestamp, tz=timezone.utc).astimezone(mexico_zone)

    def formatTime(self, record, datefmt=None):
        dt = self.converter(record.created)
        if datefmt:
            return dt.strftime(datefmt)
        return dt.isoformat()

class LoggingConfig:

    def __init__(self):
        self.logger = logging.getLogger()

    def setup_logging(self):
        if self.logger.hasHandlers():
            self.logger.handlers.clear()

        self.logger.setLevel(logging.DEBUG)

        log_directory = "logs"
        os.makedirs(log_directory, exist_ok=True)

        date_range = self.get_log_date_range()
        debug_log_file = os.path.join(log_directory, f'debug_{date_range}.log')
        info_log_file = os.path.join(log_directory, f'info_{date_range}.log')

        debug_handler = TimedRotatingFileHandler(debug_log_file, when='midnight', interval=1, backupCount=retention_days)
        info_handler = TimedRotatingFileHandler(info_log_file, when='midnight', interval=1, backupCount=retention_days)
        console_handler = logging.StreamHandler()

        debug_handler.setLevel(logging.DEBUG)
        info_handler.setLevel(logging.INFO)
        console_handler.setLevel(logging.INFO)

        time_format = '%Y-%m-%d %H:%M:%S'

        debug_formatter = MexicoFormatter('%(asctime)s - %(module)s.%(funcName)s - %(levelname)s <-> %(message)s', datefmt=time_format)
        info_formatter = MexicoFormatter('%(asctime)s - %(levelname)s <-> %(message)s', datefmt=time_format)

        debug_handler.setFormatter(debug_formatter)
        info_handler.setFormatter(info_formatter)
        console_handler.setFormatter(info_formatter)

        debug_handler.addFilter(self.DebugFilter())
        info_handler.addFilter(self.InfoFilter())
        console_handler.addFilter(self.InfoFilter())

        self.logger.addHandler(debug_handler)
        self.logger.addHandler(info_handler)
        self.logger.addHandler(console_handler)

        self.suppress_third_party_logs()
        return self.logger

    def get_log_date_range(self):
        """Return a string for log filename based on retention_days."""
        today = datetime.now(mexico_zone)
        if retention_days <= 1:
            return today.strftime('%Y-%m-%d')
        else:
            end_date = today + timedelta(days=retention_days - 1)
            return f"{today.strftime('%Y-%m-%d')}_to_{end_date.strftime('%Y-%m-%d')}"

    def suppress_third_party_logs(self):
        noisy_loggers = [
            "pika", "aio_pika", "asyncio",
            "pika.adapters.utils.connection_workflow", "_AsyncTransportBase"
        ]
        for name in noisy_loggers:
            logging.getLogger(name).setLevel(logging.WARNING)

    class DebugFilter(logging.Filter):
        def filter(self, record):
            if debug_log_flag:
                return record.levelno in [logging.DEBUG, logging.ERROR, logging.CRITICAL]
            return record.levelno in [logging.ERROR, logging.CRITICAL]

    class InfoFilter(logging.Filter):
        def filter(self, record):
            if info_log_level:
                return record.levelno == logging.INFO
            elif warning_log_level:
                return record.levelno == logging.WARNING
            return record.levelno in [logging.INFO, logging.WARNING]
