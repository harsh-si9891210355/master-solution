"""
File : image_conversion.py
Description : Convert image to/from base64 string format using OpenCV
Created on : 03 March 2024
Author : HCLTech
E-mail :
"""

import cv2
import base64
import numpy as np
from src.python.app.exceptions.base_exception import ImageConversionException
from src.python.app.utils.logger import LoggingConfig

logger = LoggingConfig().setup_logging()

class ImageConversion:
    """
    Image conversion utility class for base64 encoding and decoding
    """

    def convert_to_base64(self, image):
        """
        Convert OpenCV image (ndarray) to base64 string

        Parameters
        ----------
        image : np.ndarray
            Image to convert

        Returns
        -------
        str
            Base64-encoded JPEG string
        """
        try:
            if image is None:
                raise ValueError("Input image is None.")

            retval, buffer = cv2.imencode('.jpg', image)
            if not retval:
                raise ValueError("cv2.imencode failed.")

            data = base64.b64encode(buffer)
            return data.decode("utf-8")

        except Exception as e:
            logger.error(f"Exception in convert_to_base64: {e}")
            raise ImageConversionException(f"convert_to_base64 failed: {e}")

    def convert_to_image(self, msg):
        """
        Convert base64 string to OpenCV image (ndarray)

        Parameters
        ----------
        msg : str or bytes
            Base64-encoded JPEG image

        Returns
        -------
        np.ndarray
            Decoded OpenCV image (BGR)

        Raises
        ------
        ImageConversionException
            If decoding fails
        """
        try:
            if not msg:
                raise ValueError("Empty base64 input.")

            if isinstance(msg, str):
                msg = msg.encode("utf-8")

            img_decode = base64.b64decode(msg)
            jpg_as_np = np.frombuffer(img_decode, dtype=np.uint8)
            img = cv2.imdecode(jpg_as_np, flags=cv2.IMREAD_COLOR)

            if img is None:
                raise ValueError("cv2.imdecode returned None. Possibly corrupt base64 data.")

            return img

        except Exception as e:
            logger.error(f"Exception in convert_to_image: {e}")
            raise ImageConversionException(f"convert_to_image failed: {e}")

img_util = ImageConversion()
