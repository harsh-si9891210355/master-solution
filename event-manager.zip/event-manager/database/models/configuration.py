from sqlalchemy import Column, Integer, String, Float, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, Integer

Base = declarative_base()


class Configuration(Base):
    """
    Defines the configuration for the system.

    Attributes:
        - id (int): Primary key, auto-incremented.
        - parameter (str): Key or parameter name of the configuration.
        - value (str): Value for the configuration.
        - label (str): Label to group/configure purpose (e.g., AI_MODEL, SYSTEM).
        - input_type (str): Type of input (e.g., number, text).
        - min_value (float): Minimum allowed value.
        - max_value (float): Maximum allowed value.
        - default_value (str): Default value.
        - is_superadmin_only (int): Indicates if the configuration is only accessible by super admins.

    Author:
        HCLTech
    """

    __tablename__ = "configuration"

    id = Column(Integer, primary_key=True, autoincrement=True)
    parameter = Column(String(255), nullable=False, unique=True)
    value = Column(String(255), nullable=True)
    label = Column(String(255), nullable=True)
    input_type = Column(String(50), nullable=True)
    min_value = Column(Float, nullable=True)
    max_value = Column(Float, nullable=True)
    default_value = Column(String(255), nullable=True)
    is_superadmin_only = Column(Boolean, default=True)
