"""
File: webhook_server.py
Description: FastAPI server for receiving video webhook events and processing them
Created on: 08-04-2025
Author: HCLTech
"""

import os
import json
import time
import threading
import datetime
import subprocess
import requests
import uvicorn
from zoneinfo import ZoneInfo 

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from queue import Queue

from src.python.app.common.event_generation_handler import EventGenerationHandler
from src.python.app.utils.create_dbevent import CreateDBEvent
from src.python.app.utils.logger import LoggingConfig
from src.python.app.utils.minio_video_uploader import MinioUploader
from src.python.app.utils.web_socket_event_notifier import WebSocketEventNotifier
from src.python.app.constant.project_constant import Constant


logger = LoggingConfig().setup_logging()
app = FastAPI()

# --- Load environment and constants ---
load_dotenv()
AUTH_TOKEN = os.getenv("WEBHOOK_AUTH_TOKEN")
if not AUTH_TOKEN:
    raise ValueError("WEBHOOK_AUTH_TOKEN not found in .env file")

# --- Security & Directory Setup ---
security = HTTPBearer()
video_queue = Queue()

SAVE_DIRECTORY = Constant.IDRIVE_TEMP_FOLDER
os.makedirs(SAVE_DIRECTORY, exist_ok=True)
os.chmod(SAVE_DIRECTORY, 0o777)

# --- Token Verifier ---
def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if credentials.scheme.lower() != Constant.TOKEN_SCHEME:
        raise HTTPException(status_code=403, detail=Constant.INVALID_TOKEN_SCHEME)
    if credentials.credentials != AUTH_TOKEN:
        raise HTTPException(status_code=403, detail=Constant.INVALID_TOKEN)

@app.get(Constant.HEALTH_ENDPOINT)
def health_check():
    return {Constant.STATUS: Constant.STATUS_OK}

# --- Webhook Receiver ---
@app.post(Constant.WEBHOOK_ENDPOINT)
async def receive_video(request: Request, credentials: HTTPAuthorizationCredentials = Depends(verify_token)):
    try:
        payload = await request.json()
        event_type = payload.get(Constant.EVENT_TYPE_KEY)

        if event_type == Constant.EVENT_TYPE_STATUS:
            return {Constant.STATUS: Constant.STATUS_IGNORED}

        elif event_type == Constant.EVENT_TYPE_EVENT:
            data = payload.get(Constant.DATA_KEY)
            if not data:
                raise HTTPException(status_code=400, detail=Constant.MISSING_DATA)

            video_url = data.get(Constant.VIDEO_URL)
            reviews = data.get(Constant.REVIEWS_KEY, [])
            object_name = None
            decode_epoch_time = None

            record_date = data.get("record_date", None)
            download_date = data.get("download_date", None)

            vehicle_name = data.get("vehicle")["vehicle_name"]

            if isinstance(reviews, list) and reviews:
                first_review = reviews[0]
                object_name = first_review.get(Constant.REVIEW_KEY) 
                review_date = first_review.get(Constant.REVIEW_DATE)
            if object_name not in Constant.ACCEPTANCE_KEYS:
                logger.info(f"Ignoring event with review key: '{object_name}' (not in acceptance list).")
                return {
                    Constant.STATUS: Constant.STATUS_IGNORED,
                    Constant.MESSAGE: f"Event '{object_name}' is not in the acceptance list."
                }
            decode_epoch_time = datetime.datetime.now().strftime(Constant.DATETIME_FORMAT)
            created_date_time = datetime.datetime.now()

            camera_asset_id = data.get(Constant.DEVICE_KEY, {}).get(Constant.SERIAL_NUMBER_KEY)
            frame_id = None
            location_id = None

            if not video_url:
                raise HTTPException(status_code=400, detail=Constant.MISSING_VIDEO_URL)

            metadata = {
                Constant.VIDEO_URL: video_url,
                Constant.DECODE_EPOCH_TIME: decode_epoch_time,
                Constant.CREATED_DATETIME: created_date_time,
                Constant.CAMERA_ASSET_ID: camera_asset_id,
                Constant.FRAME_ID: frame_id,
                Constant.LOCATION_ID: location_id,
                Constant.OBJECT_NAME: object_name,
                "review_date":review_date,
                "record_date":record_date,
                "download_date":download_date,
                "vehicle_name":vehicle_name

            }

            # Safe filename construction
            timestamp_str = datetime.datetime.now().strftime(Constant.DATETIME_FORMAT)
            safe_camera_name = (camera_asset_id or Constant.DEFAULT_CAMERA).replace(" ", "_").replace("/", "_")
            safe_review_key = (object_name or Constant.DEFAULT_REVIEW_KEY).replace(" ", "_").replace("/", "_")

            raw_file_name = f"{Constant.RAW_PREFIX}_{safe_camera_name}_{safe_review_key}_{timestamp_str}.mp4"
            converted_file_name = f"{safe_camera_name}_{safe_review_key}_{timestamp_str}.mp4"

            raw_video_path = os.path.join(SAVE_DIRECTORY, raw_file_name)
            converted_video_path = os.path.join(SAVE_DIRECTORY, converted_file_name)

            # --- Download video ---
            response = requests.get(video_url, stream=True)
            if response.status_code == 200:
                with open(raw_video_path, "wb") as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                logger.info(f"Downloaded video to {raw_video_path}")
            else:
                raise HTTPException(status_code=400, detail=Constant.FAILED_VIDEO_DOWNLOAD)

            # --- Convert using FFmpeg ---
            ffmpeg_cmd = [
                Constant.FFMPEG_BIN,
                Constant.OVERWRITE_FLAG,
                Constant.INPUT_FLAG, raw_video_path,
                Constant.CODEC_FLAG, Constant.VIDEO_CODEC,
                Constant.PIX_FMT_FLAG, Constant.PIX_FMT,
                converted_video_path
            ]

            try:
                subprocess.run(ffmpeg_cmd, check=True)
                logger.debug(f"Video converted: {converted_video_path}")
            except subprocess.CalledProcessError as e:
                logger.error(f"FFmpeg error: {str(e)}")
                raise HTTPException(status_code=500, detail=Constant.CONVERSION_FAILED)

            if os.path.exists(raw_video_path):
                os.remove(raw_video_path)

            video_queue.put({"metadata": metadata, "local_path": converted_video_path})
            return {Constant.STATUS: Constant.STATUS_SUCCESS, Constant.MESSAGE: Constant.VIDEO_QUEUED}

        else:
            raise HTTPException(status_code=400, detail=Constant.UNSUPPORTED_EVENT_TYPE)

    except Exception as e:
        logger.exception(Constant.EXCEPTION_WEBHOOK_FAILED)
        raise HTTPException(status_code=500, detail=Constant.WEBHOOK_FAILED)

# --- Background Queue Processor ---
def process_queue():
    while True:
        if not video_queue.empty():
            task = video_queue.get()
            try:
                metadata = task["metadata"]
                local_path = task["local_path"]

                # Placeholder for detection output
                frames_range = "0,0"
                mexico_time = datetime.datetime.now(datetime.timezone.utc).astimezone(ZoneInfo("America/Mexico_City"))
                timestamp_first_frame = mexico_time.strftime('%Y-%m-%dT%H:%M:%S.%f')
                timestamp_last_frame = mexico_time.strftime('%Y-%m-%dT%H:%M:%S.%f')
                decode_epoch_time = metadata.get(Constant.DECODE_EPOCH_TIME)
                if decode_epoch_time:
                    dt = datetime.datetime.strptime(decode_epoch_time, Constant.DATETIME_FORMAT)
                    dt = dt.replace(tzinfo=datetime.timezone.utc).astimezone(ZoneInfo("America/Mexico_City"))
                    decode_epoch_time = dt.strftime('%Y-%m-%dT%H:%M:%S.%f')
                else:
                    decode_epoch_time = datetime.datetime.now(datetime.timezone.utc).astimezone(
                        ZoneInfo("America/Mexico_City")
                    ).strftime('%Y-%m-%dT%H:%M:%S.%f')

                frame_id = metadata.get(Constant.FRAME_ID)
                camera_asset_id = metadata.get(Constant.CAMERA_ASSET_ID)
                object_name = metadata.get(Constant.OBJECT_NAME)
                cluster = object_name
                i_drive_event = metadata.get(Constant.IDRIVE_EVENT)
                camera_id = Constant.IDRIVE_CAMERA_ID

                location_id = Constant.UNKNOWN_MAPPPING.get(Constant.LOCATION_KEY)
                usecase_id = Constant.UNKNOWN_MAPPPING.get(Constant.USECASE_KEY)

                evidence_video_on_nas, evidence_url = MinioUploader.upload_video(local_path, Constant.IDRIVE_MINIO_FOLDER) if local_path else (None, None)
                if not evidence_url:
                    logger.warning(Constant.MISSING_EVIDENCE_UPLOAD)

                event_data = EventGenerationHandler().prepare_event_data(
                    camera_id, location_id, camera_asset_id, object_name,
                    object_name, decode_epoch_time, evidence_url, cluster,
                    usecase_id, Constant.REQUEST_STATUS_SUCCESS
                )

                if event_data[Constant.SENSOR_EVENT_DATA]is None:
                    event_data[Constant.SENSOR_EVENT_DATA]= object_name


                if local_path and os.path.exists(local_path):
                    os.remove(local_path)
                    logger.debug(f"Cleaned up: {local_path}")

                event_stream_quality=1

                event_logged, event_id, event_uid = CreateDBEvent._add_event_generator_data(
                    event_data, 1, frames_range,timestamp_first_frame,
                    timestamp_last_frame, True, True,
                    evidence_video_on_nas, Constant.EVENT_TYPE_IDRIVE, event_stream_quality
                )
                event_manager_end_time = datetime.datetime.now(ZoneInfo("America/Mexico_City")).strftime('%Y-%m-%dT%H:%M:%S.%f')
                ws_sent = WebSocketEventNotifier.send_event(
                    event_id, event_data, 1, frames_range,
                    timestamp_last_frame, True, True,
                    evidence_video_on_nas, event_manager_end_time, event_uid
                )

                review_date = metadata["review_date"]
                download_date = metadata["download_date"]
                record_date = metadata["record_date"]
                vehicle_name = metadata["vehicle_name"]

                logger.info(f"[event_uid:{event_uid}], "
                f"current time in mexico: {timestamp_last_frame}, "
                f"vehicle_id: {vehicle_name},"
                f"review_date: {review_date}, "
                f"download_date: {download_date}, "
                f"record_date: {record_date}"
                )


                if all([event_logged, ws_sent]):
                    logger.info(f"[EVENT] [{i_drive_event}] successfully handled and sent")

            except Exception as e:
                logger.error(f"Queue Processing Error: {str(e)}")
        time.sleep(1)

def run_fastapi():
    uvicorn.run(
        app,
        host=Constant.SERVER_HOST,
        port=Constant.SERVER_PORT,
        log_level=Constant.LOG_LEVEL
    )

def start_webhook_server():
    threading.Thread(target=process_queue, daemon=True).start()
    threading.Thread(target=run_fastapi, daemon=True).start()
    logger.info("Webhook server and background processor started.")
