"""
File        : minio_uploader.py
Description : Uploads video files to MinIO storage with retry mechanism and provides public URL.
Created on  : 05-March-2025
Author      : HCLTech
"""

import os
import time
import mimetypes
from minio import Minio
from urllib.parse import quote
from minio.error import S3Error
from src.python.app.common.config_manager import cfg
from src.python.app.constant.project_constant import Constant
from src.python.app.constant.global_data import GlobalData
from src.python.app.utils.logger import LoggingConfig

logger = LoggingConfig().setup_logging()

class MinioUploader:
    """
    A class to handle MinIO client connection and video uploads with a retry mechanism.
    """

    MAX_RETRIES = 3
    RETRY_DELAY = 5  # seconds between retries

    def __init__(self):
        """
        Initializes the MinIO client using credentials from the config
        and ensures the configured bucket exists.
        """
        self.endpoint = cfg.get_environment_config(Constant.CONFIG_MINIO_SERVER_IP)
        self.access_key = cfg.get_environment_config(Constant.CONFIG_MINIO_ACCESS_KEY)
        self.secret_key = cfg.get_environment_config(Constant.CONFIG_MINIO_SECRET_KEY)
        self.bucket_name = cfg.get_environment_config(Constant.CONFIG_MINIO_BUCKET_NAME)
        self.client = self._connect_with_retry()
        logger.info(f"MinIO connection established: {self.client}")
        GlobalData.minio_client = self.client

    def _connect(self):
        """
        Establishes a connection to the MinIO server and ensures the bucket exists.

        Returns:
            Minio: An instance of the connected Minio client, or None on failure.
        """
        try:
            client = Minio(
                self.endpoint.replace("http://", ""),
                access_key=self.access_key,
                secret_key=self.secret_key,
                secure=False
            )

            if not client.bucket_exists(self.bucket_name):
                client.make_bucket(self.bucket_name)
                logger.info(f"Bucket '{self.bucket_name}' created.")

            return client
        except S3Error as e:
            logger.error(f"MinIO connection error: {e}")
            return None

    def _connect_with_retry(self):
        """
        Attempts to connect to MinIO with infinite retries until successful.

        Returns:
            Minio: A successfully connected Minio client.
        """
        attempt = 0
        while True:
            client = self._connect()
            if client:
                return client
            attempt += 1
            logger.warning(f"[Attempt {attempt}] Retrying MinIO connection in {self.RETRY_DELAY} seconds...")
            time.sleep(self.RETRY_DELAY)

    @staticmethod
    def upload_video(file_path, folder, object_name=None):
        """
        Uploads a video file to the configured MinIO bucket.

        Args:
            file_path (str): Local path to the video file.
            folder (str): Folder path inside the bucket to upload the file to.
            object_name (str, optional): Custom name for the object in MinIO. Defaults to the file's basename.

        Returns:
            tuple: (bool success, str file_url or None)
        """
        if not os.path.exists(file_path):
            logger.error(f"File not found: {file_path}")
            return False, None

        if object_name is None:
            object_name = os.path.basename(file_path)

        object_path = f"{folder}/{object_name}"

        try:
            if GlobalData.minio_client is None:
                GlobalData.minio_client = MinioUploader()._connect_with_retry()

            content_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"

            GlobalData.minio_client.fput_object(
                cfg.get_environment_config(Constant.CONFIG_MINIO_BUCKET_NAME),
                object_path,
                file_path,
                content_type=content_type
            )

            encoded_object_path = quote(object_path)
            minio_endpoint = cfg.get_environment_config(Constant.CONFIG_MINIO_ENDPOINT).rstrip('/')
            bucket_name = cfg.get_environment_config(Constant.CONFIG_MINIO_BUCKET_NAME)
            file_url = f"{minio_endpoint}/{bucket_name}/{encoded_object_path}"

            return True, file_url

        except S3Error as e:
            logger.error(f"S3 upload failed: {e}")
            return False, None

        except Exception as e:
            logger.exception("Unexpected error during upload")
            return False, None
