"""
File : utilities.py
Description : This manages utils of the project.
Created on : 03-March-2025
Author :  HCLTech
"""

import os
import math
import base64
import cv2
import numpy as np
import random
import string
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.constant.global_data import GlobalData
from src.python.app.utils.logger import LoggingConfig
from src.python.app.common.config_manager import cfg
import time

logger = LoggingConfig().setup_logging()

class Utilities:
    """
    This class contains utility functions
    """

    def __init__(self):
        pass
    
    def get_queue_name_for_usecase(self,usecase_name):
        queue_mapping = {
            constant.WALKING_NO_WALK_ZONE_USECASE: constant.WALKING_NO_WALK_ZONE_QUEUE,
            constant.DRIVER_AWARENESS_USECASE: constant.DRIVER_AWARENESS_QUEUE,
            constant.NO_PPE_USECASE: constant.NO_PPE_QUEUE,
            constant.SLEEPING_WORK_ZONE_USECASE: constant.SLEEPING_WORK_ZONE_QUEUE,
            constant.CELL_PHONE_WORK_ZONE_USECASE: constant.CELL_PHONE_WORK_ZONE_QUEUE,
            constant.SPEEDING_USECASE: constant.SPEEDING_QUEUE,
            constant.GOODS_OBSTRUCTING_ZONE_USECASE: constant.GOODS_OBSTRUCTING_ZONE_QUEUE,
            constant.LEAVING_WORK_ZONE_USECASE: constant.LEAVING_WORK_ZONE_QUEUE,
            constant.FACIAL_RECOGNITION_USECASE: constant.FACIAL_RECOGNITION_QUEUE,
        }
    
        return queue_mapping.get(usecase_name, None)  
    
    def get_global_queue_for_usecase(self,usecase_name):
        
        global_queue_mapping = {
           constant.WALKING_NO_WALK_ZONE_USECASE: GlobalData.walking_no_walk_zone_queue,
            constant.DRIVER_AWARENESS_USECASE: GlobalData.driver_awareness_queue,
            constant.NO_PPE_USECASE: GlobalData.no_ppe_queue,
            constant.SLEEPING_WORK_ZONE_USECASE: GlobalData.sleeping_work_zone_queue,
            constant.CELL_PHONE_WORK_ZONE_USECASE: GlobalData.cell_phone_work_zone_queue,
            constant.SPEEDING_USECASE: GlobalData.speeding_queue,
            constant.GOODS_OBSTRUCTING_ZONE_USECASE: GlobalData.goods_obstructing_zone_queue,
            constant.LEAVING_WORK_ZONE_USECASE: GlobalData.leaving_work_zone_queue,
            constant.FACIAL_RECOGNITION_USECASE: GlobalData.facial_recognition_queue,            
        }
        return global_queue_mapping.get(usecase_name, None)
          
    def get_current_epoch_in_milliseconds(self):
        """
        Get current epoch time in ms
        """
        value = time.time()
        value = value * 10**3
        return int(value)
    
    

    def save_base64_image(self, base64_str, save_dir, filename):
        """
        Converts a base64 image string to an OpenCV image and saves it.

        Args:
            base64_str (str): Base64-encoded image string.
            save_dir (str): Directory where the image should be saved.
            filename (str): Name of the output image file.

        Returns:
            str: Full path to the saved image if successful, else None.
        """
        try:
            os.makedirs(save_dir, exist_ok=True)

            # Decode base64 to OpenCV image
            image_data = base64.b64decode(base64_str)
            np_array = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(np_array, cv2.IMREAD_COLOR)

            if image is None:
                logger.error("Decoded image is None")
                return None

            image_path = os.path.join(save_dir, filename)
            success = cv2.imwrite(image_path, image)

            if success:
                logger.info(f"[UTIL] Saved image at {image_path}")
                return image_path
            else:
                logger.error(f"[UTIL] Failed to write image at {image_path}")
                return None

        except Exception as e:
            logger.error(f"[UTIL] Failed to save base64 image: {e}")
            return None

    
    
    def get_interval_value_for_event(self, usecase_name):
        """
        Returns the interval value (from GlobalData) for the given usecase.
        """
        usecase_interval_value = {
            constant.WALKING_NO_WALK_ZONE_USECASE: GlobalData.walking_in_no_walk_zone_interval_in_seconds,
            constant.NO_PPE_USECASE: GlobalData.no_ppe_event_interval_in_seconds,
            constant.SLEEPING_WORK_ZONE_USECASE: GlobalData.sleeping_in_work_zone_interval_in_seconds,
            constant.CELL_PHONE_WORK_ZONE_USECASE: GlobalData.cell_phone_in_work_zone_interval_in_seconds,
            constant.SPEEDING_USECASE: GlobalData.speeding_interval_in_seconds,
            constant.GOODS_OBSTRUCTING_ZONE_USECASE: GlobalData.goods_obstructing_zone_interval_in_seconds,
            constant.FACIAL_RECOGNITION_USECASE: GlobalData.facial_recognition_interval_in_seconds,
            constant.LEAVING_WORK_ZONE_USECASE:GlobalData.leaving_work_zone_interval_in_seconds,
        }
    
        return usecase_interval_value.get(usecase_name, None)

    def generate_unique_id(self):
        letters = random.choices(string.ascii_uppercase, k=3)
        digits = random.choices(string.digits, k=3)
        id_chars = letters + digits
        random.shuffle(id_chars)
        return ''.join(id_chars)
    

    def composite_two_row_centered(self, frames, out_h=720, out_w=1280, pad=10):
        """
        Takes a list of base64-encoded frames, decodes them to images,
        and builds a centered composite grid.

        For n = 1:
            → put the frame in the center of full canvas

        For n = 2:
            → put both frames in a single centered row

        For n >= 3:
            → original 2-row behavior remains unchanged
        """

        n = len(frames)
        if n == 0:
            logger.error("[UTIL] No frames provided to composite function.")
            raise ValueError("No frames provided")

        # -------------------------
        # BASE64 → OpenCV Decode
        # -------------------------
        decoded_frames = []
        for idx, b64 in enumerate(frames):
            try:
                img_bytes = base64.b64decode(b64)
                arr = np.frombuffer(img_bytes, np.uint8)
                img = cv2.imdecode(arr, cv2.IMREAD_COLOR)

                if img is None:
                    logger.error(f"[UTIL] Failed to decode frame at index {idx}")
                    continue

                decoded_frames.append(img)
            except Exception as e:
                logger.error(f"[UTIL] Base64 decode error at index {idx}: {e}")
                continue

        if len(decoded_frames) == 0:
            logger.error("[UTIL] All frames failed to decode")
            raise ValueError("No valid frames to composite")

        frames = decoded_frames
        n = len(frames)

        # ------------------------------------
        # SPECIAL CASE → EXACTLY 1 FRAME
        # ------------------------------------
        if n == 1:
            canvas = np.zeros((out_h, out_w, 3), dtype=np.uint8)

            def fix_channels(img):
                return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR) if img.ndim == 2 else img

            def resize_keep_ar(img, max_h, max_w):
                h, w = img.shape[:2]
                scale = min(max_h / h, max_w / w)
                nh, nw = int(h * scale), int(w * scale)
                return cv2.resize(img, (nw, nh))

            frame = resize_keep_ar(fix_channels(frames[0]), out_h, out_w)

            oy = (out_h - frame.shape[0]) // 2
            ox = (out_w - frame.shape[1]) // 2

            canvas[oy:oy + frame.shape[0], ox:ox + frame.shape[1]] = frame
            return canvas

        # ------------------------------------
        # SPECIAL CASE → EXACTLY 2 FRAMES (SINGLE ROW)
        # ------------------------------------
        if n == 2:
            canvas = np.zeros((out_h, out_w, 3), dtype=np.uint8)

            def fix_channels(img):
                return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR) if img.ndim == 2 else img

            def resize_keep_ar(img, max_h, max_w):
                h, w = img.shape[:2]
                scale = min(max_h / h, max_w / w)
                nh, nw = int(h * scale), int(w * scale)
                return cv2.resize(img, (nw, nh))

            # Cell dimensions for 2 frames in 1 row
            cell_h = out_h - pad * 2
            cell_w = (out_w - pad * 3) // 2

            y = pad

            # Place both frames centered in a single row
            for i in range(2):
                try:
                    x = pad + i * (cell_w + pad)
                    frame = resize_keep_ar(fix_channels(frames[i]), cell_h, cell_w)

                    ox = x + (cell_w - frame.shape[1]) // 2
                    oy = y + (cell_h - frame.shape[0]) // 2

                    canvas[oy:oy + frame.shape[0], ox:ox + frame.shape[1]] = frame
                except Exception as e:
                    logger.error(f"[UTIL] Failed placing frame {i}: {e}")

            return canvas

        # ------------------------------------
        # NORMAL LOGIC FOR n >= 3 (2-ROW LAYOUT)
        # ------------------------------------
        top_count = math.ceil(n / 2)
        bottom_count = n - top_count

        # Cell width/height limits
        cell_h_limit = (out_h - pad * 3) // 2
        cell_w = (out_w - pad * (top_count + 1)) // top_count

        # Blank canvas
        canvas = np.zeros((out_h, out_w, 3), dtype=np.uint8)

        def fix_channels(img):
            if img.ndim == 2:
                return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
            return img

        def resize_keep_ar(img, max_h, max_w):
            h, w = img.shape[:2]
            scale = min(max_h / h, max_w / w)
            nh, nw = int(h * scale), int(w * scale)
            return cv2.resize(img, (nw, nh))

        # ---------------------------------------------------------
        # 1. Calculate ACTUAL row height needed
        # ---------------------------------------------------------
        max_row_h = 0
        for f in frames:
            h, w = f.shape[:2]
            scale = min(cell_h_limit / h, cell_w / w)
            nh = int(h * scale)
            if nh > max_row_h:
                max_row_h = nh
        
        # Total content height = 2 rows + 1 padding between them
        total_content_h = max_row_h * 2 + pad
        
        # Center the entire block vertically
        start_y = (out_h - total_content_h) // 2
        
        # ----------------------------
        # PLACE TOP ROW
        # ----------------------------
        # Row 1 Y position
        y_top = start_y  

        for i in range(top_count):
            try:
                x = pad + i * (cell_w + pad)
                frame = resize_keep_ar(fix_channels(frames[i]), cell_h_limit, cell_w)

                ox = x + (cell_w - frame.shape[1]) // 2
                oy = y_top + (max_row_h - frame.shape[0]) // 2 

                canvas[oy:oy + frame.shape[0], ox:ox + frame.shape[1]] = frame
            except Exception as e:
                logger.error(f"[UTIL] Failed placing top frame {i}: {e}")

        # ----------------------------
        # PLACE BOTTOM ROW (CENTERED)
        # ----------------------------
        if bottom_count > 0:
            # Row 2 Y position
            y_bottom = y_top + max_row_h + pad

            top_total_w = top_count * cell_w + (top_count + 1) * pad
            bottom_total_w = bottom_count * cell_w + (bottom_count + 1) * pad

            left_margin = (top_total_w - bottom_total_w) // 2
            base_x = left_margin

            for j in range(bottom_count):
                try:
                    x = base_x + pad + j * (cell_w + pad)
                    frame = resize_keep_ar(fix_channels(frames[top_count + j]), cell_h_limit, cell_w)

                    ox = x + (cell_w - frame.shape[1]) // 2
                    oy = y_bottom + (max_row_h - frame.shape[0]) // 2

                    canvas[oy:oy + frame.shape[0], ox:ox + frame.shape[1]] = frame
                except Exception as e:
                    logger.error(f"[UTIL] Failed placing bottom frame {j}: {e}")

        return canvas





util = Utilities()