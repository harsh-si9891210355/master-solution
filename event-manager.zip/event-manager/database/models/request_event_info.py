
from src.python.app.utils.utilities import util
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, Integer, SmallInteger, CheckConstraint, BIGINT, DateTime
from sqlalchemy.dialects.mysql import LONGTEXT

Base = declarative_base()

class RequestEventInfo(Base):
    """
    Create a request_event_info table
    """
    __tablename__ = 'events'
    
    unique_event_id = Column(String(6), nullable=False, default=util.generate_unique_id) 
    event_id = Column(Integer, primary_key=True, autoincrement=True)
    camera_id = Column(Integer, nullable=False)
    camera_asset_id = Column(String(255), nullable=False)
    location_id = Column(Integer, nullable=False)
    event_timestamp = Column(DateTime, nullable=True)
    usecase_id = Column(Integer, nullable=True)
    event_data = Column(LONGTEXT, nullable=True)
    evidence_storage_path = Column(String(400), nullable=True)
    number_of_frames = Column(Integer, nullable=True)
    frames_range = Column(String(400), nullable=True)
    created_date_time = Column(DateTime, nullable=True)
    decode_timestamp = Column(DateTime, nullable=True)
    event_end_time  = Column(DateTime, nullable=True)
    is_email_sent = Column(SmallInteger, nullable=False, default=1)
    is_notification_sent_on_milestone = Column(SmallInteger, nullable=False, default=1)
    is_evidence_sent_on_nas = Column(SmallInteger, nullable=False, default=1)
    request_status = Column(SmallInteger,CheckConstraint('request_status IN (1, 2, 3)', name='check_request_status'), nullable=False, default=1)
    event_type = Column(Integer, CheckConstraint('event_type_id IN (1, 2)', name='check_event_type_id'), nullable=True)
    event_stream_quality = Column(SmallInteger, nullable=False, default=1)

    def __init__(self, camera_id, camera_asset_id, location_id, event_timestamp, usecase_id, event_data, 
                 evidence_storage_path, number_of_frames, frames_range, created_date_time,
                 decode_timestamp, is_email_sent, is_notification_sent_on_milestone,
                 is_evidence_sent_on_nas, request_status, event_type, event_end_time,event_stream_quality):
        
        self.unique_event_id = util.generate_unique_id()
        self.camera_id = camera_id
        self.camera_asset_id = camera_asset_id
        self.location_id = location_id
        self.event_timestamp = event_timestamp
        self.usecase_id = usecase_id
        self.event_data = event_data
        self.evidence_storage_path = evidence_storage_path
        self.number_of_frames = number_of_frames
        self.frames_range = frames_range
        self.created_date_time = created_date_time
        self.decode_timestamp = decode_timestamp
        self.is_email_sent = is_email_sent
        self.is_notification_sent_on_milestone = is_notification_sent_on_milestone
        self.is_evidence_sent_on_nas = is_evidence_sent_on_nas
        self.request_status = request_status
        self.event_type = event_type
        self.event_end_time = event_end_time
        self.event_stream_quality=event_stream_quality
