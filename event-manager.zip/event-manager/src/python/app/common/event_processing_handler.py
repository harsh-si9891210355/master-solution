"""
File : event_processing_handler.py
Description : sensor_processing_handler is responsible for start, stop and pause
              event services.
Created on : 28-Feb-2025
Author : HCLTech
"""


import os
import time
import queue
import json
import threading
from zoneinfo import ZoneInfo
from datetime import datetime, timezone, timedelta
from src.python.app.common.rabbitmq_messaging_service import RabbitMQService
from src.python.app.constant.global_data import GlobalData
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.utils.utilities import util
from src.python.app.exceptions.base_exception import EventProcessingHandlerException, SensorProcessingHandlerException
from src.python.app.utils.logger import LoggingConfig
from src.python.app.common.event_generation_handler import EventGenerationHandler
from src.python.app.utils.create_dbevent import CreateDBEvent
from src.python.app.utils.web_socket_event_notifier import WebSocketEventNotifier
from src.python.app.utils.minio_video_uploader import MinioUploader
from src.python.app.common.config_manager import cfg
from src.python.app.utils.milestone_notifier import MilestoneNotifier
from src.python.app.utils.email_utils import EmailService
from src.python.app.utils.database_manager import DatabaseManager
logger = LoggingConfig().setup_logging()

import threading

event_locks = {}
lock_manager = threading.Lock()  


def get_event_lock(key: str) -> threading.Lock:
    """
    Returns a dedicated lock for each camera_asset_id + usecase_name pair.
    Ensures thread-safe creation and reuse of locks.
    """
    with lock_manager:
        if key not in event_locks:
            event_locks[key] = threading.Lock()
        return event_locks[key]
    

class EventProcessingHandler:
    """SensorProcessingHandler class responsible to start, stop
                pause and resume api.
    """

    def __init__(self):
        """
        Instantiates Sensor Processing Handler
        """
        pass

    def _thread_stored_status(self):
        try:
            thread_status = constant.FAILURE_STATUS
            GlobalData.receiver_threads = {}
            GlobalData.analysis_threads = {}
            receiver_thread_count = int(cfg.get_environment_config(
                constant.CONFIG_RECEIVER_THREAD_COUNT))
            analysis_thread_count = int(cfg.get_environment_config(
                constant.CONFIG_ANALYSIS_THREAD_COUNT))
            for usecase in [
                constant.WALKING_NO_WALK_ZONE_USECASE,
                constant.CELL_PHONE_WORK_ZONE_USECASE,
                constant.NO_PPE_USECASE,
                # constant.FACIAL_RECOGNITION_USECASE,
                constant.SLEEPING_WORK_ZONE_USECASE,
                constant.SPEEDING_USECASE,
                constant.GOODS_OBSTRUCTING_ZONE_USECASE,
                constant.LEAVING_WORK_ZONE_USECASE
            ]:
                # Create receiver threads
                current_receiver_count = (receiver_thread_count * 4 if usecase == constant.WALKING_NO_WALK_ZONE_USECASE else receiver_thread_count)
                logger.info(f"for usecase {usecase} total receiver threads : {current_receiver_count}")
                recv_threads = []
                for _ in range(current_receiver_count):
                    t = threading.Thread(
                        target=self.recv_from_event_queue, args=(usecase,))
                    recv_threads.append(t)
                GlobalData.receiver_threads[usecase] = recv_threads
                # Create analysis threads
                current_analysis_count = (analysis_thread_count * 4 if usecase == constant.WALKING_NO_WALK_ZONE_USECASE else analysis_thread_count)
                logger.info(f"for usecase {usecase} total analysis threads are : {current_analysis_count}")
                analysis_threads = []
                for _ in range(current_analysis_count):
                    if usecase == constant.SPEEDING_USECASE:
                        t = threading.Thread(target=self.analyse_speed_msgs)
                    elif usecase == constant.LEAVING_WORK_ZONE_USECASE:
                        t = threading.Thread(target=self.analyse_leaving_work_zone_msgs)
                    else:
                        t = threading.Thread(
                            target=self.analyse_queue_msgs, args=(usecase,))
                    analysis_threads.append(t)
                GlobalData.analysis_threads[usecase] = analysis_threads
 
            thread_status = constant.SUCCESS_STATUS
            return thread_status
 
        except Exception as e:
            logger.error(f"Exception in defining thread slots: {e}")
            raise EventProcessingHandlerException(
                f"Exception in defining thread slots: {e}")
 

    def trigger_sensor_processing(self):
        """
        Triggers sensor processing by initializing and starting necessary threads.

        Raises:
            SensorProcessingHandlerException: If thread execution fails.

        Returns:
            bool: SUCCESS or FAILURE status.
        """
        try:
            if not GlobalData.sensor_execution_status:
                return constant.SUCCESS_STATUS

            for usecase in GlobalData.db_usecase_name:
                recv_threads = GlobalData.receiver_threads.get(usecase, [])
                analysis_threads = GlobalData.analysis_threads.get(usecase, [])

                for i, thread in enumerate(recv_threads + analysis_threads):
                    if thread is not None:
                        if not thread.is_alive():
                            try:
                                thread.start()
                            except RuntimeError as e:
                                logger.error(
                                    f"Thread {i} for usecase {usecase} already started or finished: {e}")

            return constant.SUCCESS_STATUS

        except Exception as e:
            logger.error(f"Error in sensor processing: {e}", exc_info=True)
            raise SensorProcessingHandlerException(
                f"Error in thread execution: {e}")

    def monitor_threads(self, interval: int = 10):
        """
        Monitor all sensor processing threads and restart any that have stopped.

        Args:
            interval (int): Number of seconds between health checks.
        """
        logger.info("Thread monitor started...")
        while True:
            try:
                for usecase in GlobalData.db_usecase_name:
                    recv_threads = GlobalData.receiver_threads.get(usecase, [])
                    analysis_threads = GlobalData.analysis_threads.get(
                        usecase, [])

                    # Check receiver threads
                    for i, thread in enumerate(recv_threads):
                        if thread is None or not thread.is_alive():
                            logger.warning(
                                f"Receiver thread {i} for {usecase} is dead or None. Restarting...")
                            new_thread = threading.Thread(
                                target=self.recv_from_event_queue, args=(usecase,))
                            new_thread.start()
                            GlobalData.receiver_threads[usecase][i] = new_thread
                            logger.warning(
                                f"Restarted receiver thread {i} for {usecase}")

                    # Check analysis threads
                    for i, thread in enumerate(analysis_threads):
                        if thread is None or not thread.is_alive():
                            logger.warning(
                                f"Analysis thread {i} for {usecase} is dead or None. Restarting...")

                            if usecase == constant.SPEEDING_USECASE:
                                new_thread = threading.Thread(
                                    target=self.analyse_speed_msgs)
                            elif usecase == constant.GOODS_OBSTRUCTING_ZONE_USECASE:
                                new_thread = threading.Thread(
                                    target=self.analyse_goods_msgs, args=(usecase,))
                            else:
                                new_thread = threading.Thread(
                                    target=self.analyse_queue_msgs, args=(usecase,))

                            new_thread.start()
                            GlobalData.analysis_threads[usecase][i] = new_thread
                            logger.warning(
                                f"Restarted analysis thread {i} for {usecase}")

                time.sleep(interval)

            except Exception as e:
                logger.error(
                    f"Exception in monitoring threads: {e}", exc_info=True)

    def recv_from_event_queue(self, usecase_name):
        """
        Continuously consumes messages from RabbitMQ one-by-one and stores them in GlobalData queue.
        Acknowledges only after successful consumption, ensuring UI reflects real-time speed.
        Reconnects on channel/connection failure.
        """

        rabbitmq_message_obj = RabbitMQService()
        queue_name = util.get_queue_name_for_usecase(usecase_name)
        logger.info(f"Starting consumer thread for queue: {queue_name}")

        if not queue_name:
            raise EventProcessingHandlerException(
                f"Queue name not found for usecase: {usecase_name}"
            )

        global_data_queue = util.get_global_queue_for_usecase(usecase_name)
        if not global_data_queue:
            raise EventProcessingHandlerException(
                f"Global queue not found for usecase: {usecase_name}"
            )

        def on_message(ch, method, properties, body):
            if not GlobalData.sensor_execution_status:
                ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
                return

            try:
                message = json.loads(
                    body.decode("utf-8") if isinstance(body, (bytes, bytearray)) else body
                )

               
                global_data_queue.put(message, timeout=2)
                ch.basic_ack(delivery_tag=method.delivery_tag)

            except json.JSONDecodeError:
                logger.warning("Invalid JSON in message, discarding.")
                ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)

            except queue.Full:
                logger.warning("Global queue is full, requeuing message.")
                ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)

            except Exception as e:
                logger.error(f"Unexpected error processing message: {e}", exc_info=True)
                ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)

        last_log_time = 0
        log_interval = 1200

        while True:
            try:
                rabbitmq_message_obj.ensure_connection()
                rabbitmq_message_obj.channel.basic_qos(prefetch_count=1)

                queue_info = rabbitmq_message_obj.channel.queue_declare(
                    queue=queue_name, passive=True
                )
                message_count = queue_info.method.message_count

                if message_count == 0:
                    current_time = time.time()
                    if current_time - last_log_time > log_interval:
                        logger.info(f"No messages in queue '{queue_name}', sleeping...")
                        last_log_time = current_time
                    time.sleep(5)
                    continue

                rabbitmq_message_obj.channel.basic_consume(
                    queue=queue_name,
                    on_message_callback=on_message,
                    auto_ack=False
                )

                logger.info(f"Started consuming from queue: {queue_name}")
                rabbitmq_message_obj.channel.start_consuming()

            except Exception as e:
                logger.error(f"recv_from_event_queue Exception: {e}", exc_info=True)
                time.sleep(5)

    def analyse_speed_msgs(self):
        """
        Analyse 'Speed' messages from queue.
        Each message contains a batch with shared metadata and a list of base64 images as frames.
        Each frame in the batch will get a slightly incremented timestamp (+0.2s).
        """
        try:
            logger.info("[SPEED] analyse_speed_msgs thread started")
            TIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"

            while GlobalData.sensor_execution_status:
                try:
                    single_message = GlobalData.speeding_queue.get(timeout=1)
                except queue.Empty:
                    time.sleep(1)
                    continue

                if not GlobalData.sensor_execution_status:
                    break

                try:
                    item = single_message[0]
                    mexico_time = datetime.now(ZoneInfo("America/Mexico_City")).strftime('%Y-%m-%dT%H:%M:%S.%f')
                    item[constant.META_FRAME_METADATA][constant.META_EVENT_MANAGER_CONSUME_TIME] = mexico_time

                    frame_id = item[constant.META_FRAME_METADATA][constant.META_FRAME_ID]
                    camera_id = item[constant.CAMERA_METADATA][constant.META_CAMERA_ID]
                    camera_asset_id = item[constant.CAMERA_METADATA][constant.META_CAMERA_ASSET_ID]
                    location_id = item[constant.CAMERA_METADATA][constant.META_LOCATION_ID]
                    usecase_name = item[constant.META_FRAME_METADATA][constant.META_USECASE_NAME]
                    output_frames = item[constant.META_FRAME_METADATA][constant.META_OUTPUT_IMAGE_DATA]
                    base_decoding_time_str = item[constant.META_FRAME_METADATA][constant.META_TIMESTAMP]

                    frame_publish_time_from_handler = item[constant.META_FRAME_METADATA][constant.META_STREAMHANDLER_SENT_TIME]
                    frame_consume_time_by_usecases = item[constant.META_FRAME_METADATA][constant.META_USECASE_CONSUME_TIME]
                    frame_sent_to_event_manager_time = item[constant.META_FRAME_METADATA][constant.META_DECODE_TIME_EPOCH]
                    frame_consume_from_event_manager = item[constant.META_FRAME_METADATA][constant.META_EVENT_MANAGER_CONSUME_TIME]


                    # ✅ Added: raw frame path and batch quality
                    raw_frame_path = item[constant.META_FRAME_METADATA][constant.META_INPUT_IMAGE_DATA]
                    batch_quality = item[constant.META_INPUT_STREAM_QUALITY]

                    key = f"{camera_asset_id}_{usecase_name}"
                    detection_desc = f"{constant.DETECTION_DICT.get(usecase_name, 'None')} + Camera: {camera_asset_id}, Location: {location_id}"

                    if isinstance(output_frames, str):
                        output_frames = [output_frames]
                    if not isinstance(output_frames, list):
                        logger.error("[SPEED] output_frames is not a list")
                        continue

                    if isinstance(raw_frame_path, str):
                        raw_frame_path = [raw_frame_path]
                    if not isinstance(raw_frame_path, list):
                        logger.error("[SPEED] raw_frame_path is not a list")
                        continue

                    base_time = datetime.strptime(base_decoding_time_str, TIME_FORMAT).replace(
                        tzinfo=ZoneInfo("America/Mexico_City")
                    )

                    detections = []
                    logger.info(f"[SPEED] Received {len(output_frames)} frames in speeding batch")

                    for idx, (proc_frame, raw_frame) in enumerate(zip(output_frames, raw_frame_path)):
                        frame_time = base_time + timedelta(seconds=0.2 * idx)
                        frame_time_str = frame_time.strftime(TIME_FORMAT)
                        frame_id_str = f"{frame_id}_{idx}"

                        detections.append(
                            (frame_id_str, frame_time_str, detection_desc, proc_frame, raw_frame, camera_id)
    )
                    self.analyse_in_event_interval(
                        base_decoding_time_str, 
                        camera_id,
                        camera_asset_id,
                        location_id,
                        detections,
                        constant.SPEEDING_USECASE,batch_quality, frame_publish_time_from_handler,frame_consume_time_by_usecases,frame_sent_to_event_manager_time, frame_consume_from_event_manager
                    )

                except Exception as e:
                    logger.error(f"[SPEED] Failed processing message: {e}", exc_info=True)

        except Exception as e:
            logger.error(f"[SPEED] analyse_speed_msgs Outer Exception: {e}", exc_info=True)
            raise SensorProcessingHandlerException(f"analyse_speed_msgs Exception: {e}")

    def analyse_queue_msgs(self, usecase_name):
        """
        Processes batched messages from the queue.
        Each message fetched from the queue is a list of JSON dictionaries (same camera & usecase).
        Adds +0.2s increment to usecase_time for each frame in the batch.
        Also passes raw_frame_data and batch_quality (from JSON) to event interval.
        """
        try:
            logger.info(f"{usecase_name} analyse_queue_msgs thread started")
 
            TIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"
 
            global_queue_data = util.get_global_queue_for_usecase(usecase_name)
            if not global_queue_data:
                raise SensorProcessingHandlerException(
                    f"Global queue not found for usecase: {usecase_name}"
                )
 
            while GlobalData.sensor_execution_status:
                try:
                    messages = global_queue_data.get(timeout=1)  # one get gives list of dicts (batch)
                except queue.Empty:
                    time.sleep(5)
                    continue
 
                try:
                    if not isinstance(messages, list):
                        logger.warning("Expected list of messages, got single object. Skipping.")
                        continue
 
                    messages.sort(
                        key=lambda msg: datetime.strptime(
                            msg[constant.META_FRAME_METADATA][constant.META_TIMESTAMP],
                            TIME_FORMAT
                        ).replace(tzinfo=ZoneInfo("America/Mexico_City"))
                    )

                    if not self._is_batch_confident_enough(messages, usecase_name):
                        logger.info(f"Skipping batch for {usecase_name} due to low average confidence.")
                        continue
 
                    first_msg = messages[0]
                    camera_id = first_msg[constant.CAMERA_METADATA][constant.META_CAMERA_ID]
                    camera_asset_id = first_msg[constant.CAMERA_METADATA][constant.META_CAMERA_ASSET_ID]
                    location_id = first_msg[constant.CAMERA_METADATA][constant.META_LOCATION_ID]
                    batch_quality = first_msg[constant.META_INPUT_STREAM_QUALITY]
                    base_time = datetime.strptime(
                        first_msg[constant.META_FRAME_METADATA][constant.META_TIMESTAMP],
                        TIME_FORMAT
                    ).replace(tzinfo=ZoneInfo("America/Mexico_City"))
 
                    frame_data_list = []
 
                    for idx, message in enumerate(messages):
                        mexico_time = datetime.now(ZoneInfo("America/Mexico_City")).strftime('%Y-%m-%dT%H:%M:%S.%f')
                        message[constant.META_FRAME_METADATA][constant.META_EVENT_MANAGER_CONSUME_TIME] = mexico_time
                        frame_id = message[constant.META_FRAME_METADATA][constant.META_FRAME_ID]
                        output_frame_data = message[constant.META_FRAME_METADATA][constant.META_OUTPUT_IMAGE_DATA]
                        raw_frame_data = message[constant.META_FRAME_METADATA][constant.META_INPUT_IMAGE_DATA]
                        usecase_name = message[constant.META_FRAME_METADATA][constant.META_USECASE_NAME]
                        decoding_time = message[constant.META_FRAME_METADATA][constant.META_TIMESTAMP]
 
                        frame_publish_time_from_handler = message[constant.META_FRAME_METADATA][constant.META_STREAMHANDLER_SENT_TIME]
                        frame_consume_time_by_usecases = message[constant.META_FRAME_METADATA][constant.META_USECASE_CONSUME_TIME]
                        frame_sent_to_event_manager_time = message[constant.META_FRAME_METADATA][constant.META_DECODE_TIME_EPOCH]
                        frame_consume_from_event_manager = message[constant.META_FRAME_METADATA][constant.META_EVENT_MANAGER_CONSUME_TIME]
 
                        detection = f"{constant.DETECTION_DICT.get(usecase_name, 'None')} + Camera: {camera_asset_id}, Location: {location_id}"
 
                        # Adjust timestamp
                        adjusted_time = base_time + timedelta(seconds=idx * 0.2)
                        adjusted_time_str = adjusted_time.strftime(TIME_FORMAT)
 
                        frame_data_list.append(
                            (frame_id, adjusted_time_str, detection, output_frame_data, raw_frame_data, camera_id)
                        )
 
                    # Process entire batch
                    self.analyse_in_event_interval(
                        decoding_time,
                        camera_id,
                        camera_asset_id,
                        location_id,
                        frame_data_list,
                        usecase_name,
                        batch_quality,
                        frame_publish_time_from_handler,
                        frame_consume_time_by_usecases,
                        frame_sent_to_event_manager_time,
                        frame_consume_from_event_manager,
                    )
 
                except Exception as inner_ex:
                    logger.error(f"Error processing batch: {inner_ex}", exc_info=True)
 
        except Exception as e:
            logger.error(f"analyse_queue_msgs Exception: {e}", exc_info=True)
            raise SensorProcessingHandlerException(f"analyse_queue_msgs Exception: {e}")


    def analyse_in_event_interval(
        self, decode_time, camera_id, camera_asset_id, location_id,
        all_detections_in_event_interval, usecase_name,batch_quality, frame_publish_time_from_handler,frame_consume_time_by_usecases,frame_sent_to_event_manager_time, frame_consume_from_event_manager
    ):
        key = f"{camera_asset_id}_{usecase_name}"
        inactivity_threshold = int(util.get_interval_value_for_event(usecase_name))

        TIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"
        DB_TIME_FORMAT = "%Y-%m-%d %H:%M:%S.%f"
        event_lock = get_event_lock(key)
        try:
            with event_lock:
            # --- Normalize frame times ---
                first_frame_time = all_detections_in_event_interval[0][1]
                last_frame_time = all_detections_in_event_interval[-1][1]

                if isinstance(first_frame_time, str):
                    first_frame_time = datetime.strptime(first_frame_time, TIME_FORMAT).replace(
                        tzinfo=ZoneInfo("America/Mexico_City")
                    )
                if isinstance(last_frame_time, str):
                    last_frame_time = datetime.strptime(last_frame_time, TIME_FORMAT).replace(
                        tzinfo=ZoneInfo("America/Mexico_City")
                    )
                # --- Check and correct the first and last frame times ---
                if last_frame_time < first_frame_time:
                    last_frame_time = first_frame_time + timedelta(seconds=2)
                    logger.info(f"Corrected last_frame_time to be 2 seconds after first_frame_time due to an anomaly.")

                # --- Get last event from DB ---
                last_event = DatabaseManager().GetLastEvent(camera_asset_id, usecase_name)

                if last_event and last_event.event_end_time:
                    last_event_end_time = last_event.event_end_time
                    if isinstance(last_event_end_time, str):
                        last_event_end_time = datetime.strptime(last_event_end_time, DB_TIME_FORMAT).replace(
                            tzinfo=ZoneInfo("America/Mexico_City")
                        )
                    elif isinstance(last_event_end_time, datetime) and last_event_end_time.tzinfo is None:
                        last_event_end_time = last_event_end_time.replace(tzinfo=ZoneInfo("America/Mexico_City"))

                    gap = (first_frame_time - last_event_end_time).total_seconds()
                    if gap < inactivity_threshold:
                        # --- Logic for extending event time with a check ---
                        new_end_time = last_frame_time
                        if new_end_time < last_event_end_time:
                            new_end_time = last_event_end_time + timedelta(seconds=2)
                            logger.info(f"Corrected new end time for extension to be 2 seconds after previous end time.")
                            
                        DatabaseManager().UpdateEndEventTimeByEventId(
                            last_event.event_id,
                            new_end_time.strftime("%Y-%m-%dT%H:%M:%S.%f")
                        )
                        event_manager_end_time = datetime.now(ZoneInfo("America/Mexico_City")).strftime('%Y-%m-%dT%H:%M:%S.%f')
                        self.log_frame_timing_info(last_event.event_id, camera_asset_id, usecase_name,decode_time, frame_publish_time_from_handler,frame_consume_time_by_usecases,frame_sent_to_event_manager_time, frame_consume_from_event_manager , event_manager_end_time)
                        logger.info(f"[EVENT] [{usecase_name}] [{key}] Event {last_event.event_id} extended.")
                        return constant.SUCCESS_STATUS

                event_generation = EventGenerationHandler()
                final_event_report, raw_tmp_path, raw_final_path, processed_tmp_path, processed_final_path = \
                    event_generation.analyse_event(all_detections_in_event_interval, camera_asset_id, usecase_name)

                # frame counts / ids / rangesusecase_timeusecase_time
                no_of_frames_in_ei = len(all_detections_in_event_interval)
                first_frame_in_ei = all_detections_in_event_interval[0][0]
                last_frame_in_ei = all_detections_in_event_interval[-1][0]
                frames_range = f"{first_frame_in_ei},{last_frame_in_ei}"

                # use the parsed datetimes for timestamps
                timestamp_first_frame_in_ei = first_frame_time
                timestamp_last_frame_in_ei = last_frame_time

                if timestamp_last_frame_in_ei < timestamp_first_frame_in_ei:
                    timestamp_last_frame_in_ei = timestamp_first_frame_in_ei + timedelta(seconds=2)
                    logger.info("Corrected new event end time to be 2 seconds after start time.")

                request_status = 1
                usecase_id = int(constant.usecase_dict.get(usecase_name))
                for object_name, detection in final_event_report:

                    # Upload processed (evidence) video if present
                    if processed_final_path:
                        try:
                            evidence_video_on_nas, evidence_url = MinioUploader.upload_video(
                                processed_final_path, "evidence_videos"
                            )
                        except Exception as up_ex:
                            logger.error(f"[EVENT] [{usecase_name}] [{key}] Failed to upload processed video: {up_ex}")
                            evidence_video_on_nas, evidence_url = None, None

                    # Upload raw final video if present
                    if raw_final_path:
                        try:
                            raw_video_on_nas, raw_video_url = MinioUploader.upload_video(
                                raw_final_path, "input_videos"
                            )
                        except Exception as up_ex:
                            logger.error(f"[EVENT] [{usecase_name}] [{key}] Failed to upload raw video: {up_ex}")
                            raw_video_on_nas, raw_video_url = None, None

                    if batch_quality :
                        final_url_for_db = raw_video_url
                        event_stream_quality = 0                 
                    else:
                        final_url_for_db = evidence_url
                        event_stream_quality = 1

                    logger.info(f"Getting stream quality is : {batch_quality}")
                    if final_url_for_db is None:
                                logger.info(f"[{usecase_name}] Evidence URL missing for object {object_name} — skipping event.")
                                continue

                    event_data = event_generation.prepare_event_data(
                        camera_id, location_id, camera_asset_id, object_name,
                        detection, decode_time, final_url_for_db, usecase_name,
                        usecase_id, request_status
                    )

                    event_type_id = 2
                    email_notification_status = True
                    notification_on_milestone_status = constant.SUCCESS_STATUS

                    if int(cfg.get_environment_config(constant.MILESTONE_NOTIFICATION_FLAG)):
                        alarm_notifier = MilestoneNotifier()
                        unique_camera_id_milestone = alarm_notifier.get_camera_id_by_name(camera_asset_id)
                        if unique_camera_id_milestone:
                            message = event_data.get(constant.SENSOR_EVENT_DATA, None)
                            notification_on_milestone_status = alarm_notifier.send_alarm(
                                unique_camera_id_milestone, usecase_name, message
                            )
                        else:
                            notification_on_milestone_status = constant.FAILURE_STATUS
                            logger.debug(f"[MILESTONE] Could not find camera '{camera_asset_id}'")

                    event_logged, event_id, event_uid = CreateDBEvent._add_event_generator_data(
                        event_data, no_of_frames_in_ei, frames_range,
                        timestamp_first_frame_in_ei, timestamp_last_frame_in_ei,
                        email_notification_status, notification_on_milestone_status,
                        evidence_video_on_nas, event_type_id,event_stream_quality
                    )
                    event_manager_end_time = datetime.now(ZoneInfo("America/Mexico_City")).strftime('%Y-%m-%dT%H:%M:%S.%f')
                    self.log_frame_timing_info(event_id, camera_asset_id, usecase_name,decode_time, frame_publish_time_from_handler,frame_consume_time_by_usecases,frame_sent_to_event_manager_time, frame_consume_from_event_manager , event_manager_end_time)

                    WebSocketEventNotifier.send_event(
                        event_id, event_data, no_of_frames_in_ei, frames_range,
                        timestamp_first_frame_in_ei.strftime('%Y-%m-%dT%H:%M:%S.%f'),
                        email_notification_status, notification_on_milestone_status,
                        evidence_video_on_nas, event_manager_end_time, event_uid
                    )

                    if event_logged and evidence_video_on_nas:
                        logger.debug(f"[EVENT] [{usecase_name}] [{key}]: Event created, MinIO: {evidence_video_on_nas}")

                # --- Cleanup all 4 video paths (safe) ---
                for path in (raw_tmp_path, raw_final_path, processed_tmp_path, processed_final_path):
                    try:
                        if path and os.path.exists(path):
                            os.remove(path)
                            logger.debug(f"[EVENT] [{usecase_name}] [{key}]: Deleted {path}")
                    except Exception as ex:
                        logger.debug(f"[EVENT] [{usecase_name}] [{key}]: Failed to delete {path}: {ex}")

                return constant.SUCCESS_STATUS

        except Exception as e:
            logger.debug(f"[EVENT] [{usecase_name}] [{key}] Exception: {e}", exc_info=True)
            raise SensorProcessingHandlerException(f"Exception in analyse_in_event_interval: {e}")


    def send_event_notification_email(self,
                                      recipients: str,
                                      name: str,
                                      device_name: str,
                                      zone: str,
                                      usecase: str,
                                      description: str,
                                      date: str,
                                      video_url: str
                                      ) -> bool:
        """
        Sends an event detection email with evidence video link.

        Args:
            recipients (List[str]): List of email addresses.
            name (str): Recipient's name or label.
            device_name (str): Name of the device that detected the event.
            zone (str): Zone/location of the event.
            usecase (str): Use case (e.g., intrusion).
            description (str): Description of the event.
            date (str): Timestamp of the event.
            video_url (str): Public URL to the evidence video.

        Returns:
            bool: True if email sent successfully, False otherwise.
        """
        try:
            subject = "Alert: Event Detected by Carrix AI"
            year = datetime.now().year

            html_content = constant.EVENT_DETECTED_TEMPLATE.format(
                name=name,
                device_name=device_name,
                zone=zone,
                usecase=usecase,
                description=description,
                date=date,
                video_url=video_url,
                year=year
            )

            plain_text = (
                f"Hello {name},\n\n"
                f"An event has been detected by Carrix AI CCTV:\n"
                f"- Device: {device_name}\n"
                f"- Zone: {zone}\n"
                f"- Usecase: {usecase}\n"
                f"- Description: {description}\n"
                f"- Date: {date}\n\n"
                f"Evidence Video: {video_url}\n\n"
                f"Regards,\nCarrix AI Team"
            )

            email_service = EmailService()
            return email_service.send_email(
                to_email=recipients,
                subject=subject,
                plain_text=plain_text,
                html_content=html_content
            )

        except Exception as e:
            print(f"Email send failed: {e}")
            return False
        

    def log_frame_timing_info(
        self,
        event_id,
        camera_asset_id,
        usecase_name,
        decode_time,
        frame_publish_time_from_handler,
        frame_consume_time_by_usecases,
        frame_sent_to_event_manager_time,
        frame_consume_from_event_manager,
        event_manager_end_time):
        """
        Logs the timing between different event pipeline stages for performance tracking.
        The timings show how long it took from frame decode → handler publish → 
        usecase processing → event manager → event manager consumed.
        """

        TIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"

        try:
            # --- Convert string timestamps to datetime ---
            decode_time_dt = datetime.strptime(decode_time, TIME_FORMAT)
            publish_time_dt = datetime.strptime(frame_publish_time_from_handler, TIME_FORMAT)
            usecase_time_dt = datetime.strptime(frame_consume_time_by_usecases, TIME_FORMAT)
            sent_to_event_mgr_dt = datetime.strptime(frame_sent_to_event_manager_time, TIME_FORMAT)
            consumed_from_event_mgr_dt = datetime.strptime(frame_consume_from_event_manager, TIME_FORMAT)
            event_manager_end_time_dt = datetime.strptime(event_manager_end_time, TIME_FORMAT)

            logger.info(f"[METADATA] getting values from queues base_decoding_time_str : {decode_time}, frame_publish_time_from_handler:{frame_publish_time_from_handler},frame_consume_time_by_usecases:{frame_consume_time_by_usecases}, frame_sent_to_event_manager_time:{frame_sent_to_event_manager_time}, frame_consume_from_event_manager:{frame_consume_from_event_manager}")

           

            # --- Calculate durations (in seconds) ---
            decode_to_publish = (publish_time_dt - decode_time_dt).total_seconds()
            usecase_analysis_time = (consumed_from_event_mgr_dt - publish_time_dt).total_seconds()
            event_manager_analysis_time = (event_manager_end_time_dt - consumed_from_event_mgr_dt).total_seconds()
            total_processing_time = (event_manager_end_time_dt - decode_time_dt).total_seconds()

            # --- Log all ---
            logger.info(
                f"[TIME_ANALYSIS] [{usecase_name}] [{camera_asset_id}] [EventID: {event_id}] "
                f"Decode→Publish: {decode_to_publish:.3f}s | "
                f"usecase_analysis_time: {usecase_analysis_time:.3f}s | "
                f"event_manager_analysis_time: {event_manager_analysis_time:.3f}s | "
                f"Total: {total_processing_time:.3f}s"
            )

        except Exception as ex:
            logger.warning(
                f"[TIME_ANALYSIS] [{usecase_name}] [{camera_asset_id}] [EventID: {event_id}] "
                f"Failed to log frame timing info: {ex}"
            )

    def _is_batch_confident_enough(self, messages, usecase_name):
        """
        Calculates average confidence for a batch.
        Applies only to WALKING_NO_WALK_ZONE_USECASE.
        Returns True if avg_confidence >= threshold else False.
        """
        try:
            
            if usecase_name != constant.WALKING_NO_WALK_ZONE_USECASE:
                return True  
            
            event_batch_average_confidence = float(GlobalData.event_batch_average_confidence)
 
            confidence_values = []
            for message in messages:
                confidence = message[constant.META_FRAME_METADATA][constant.META_FRAME_DETECTION]
                if isinstance(confidence, list):
                    conf_values = [d.get("conf", 0.0) for d in confidence if isinstance(d, dict)]
                    confidence = sum(conf_values) / len(conf_values) if conf_values else 0.0
                elif not isinstance(confidence, (int, float)):
                    confidence = 0.0
                confidence_values.append(confidence)
 
            avg_confidence = sum(confidence_values) / len(confidence_values) if confidence_values else 0.0
            logger.info(f"[{usecase_name}] Batch average confidence: {avg_confidence:.3f}")
 
            return float(avg_confidence) >= event_batch_average_confidence
 
        except Exception as ex:
            logger.error(f"Error calculating batch confidence: {ex}", exc_info=True)
            return False
        

    def analyse_leaving_work_zone_msgs(self):
        """
        Processes batched messages from the leaving_work_zone queue.
        Builds composite frames using 2-row function.
        Generates or extends events.
        This version is continuous-safe (no returns inside the main loop).
        """
        try:
            frame_width = int(cfg.get_environment_config(constant.CONFIG_EVIDENCE_VIDEO_WIDTH))
            frame_height = int(cfg.get_environment_config(constant.CONFIG_EVIDENCE_VIDEO_HEIGHT))
            padding_frames = int(cfg.get_environment_config(constant.PADDING_FOR_CONCATNATION))

            logger.info("[Leaving_WorkZone] analyse_leaving_work_zone_msgs thread initialized successfully")

            TIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"
            DB_TIME_FORMAT = "%Y-%m-%d %H:%M:%S.%f"

            while GlobalData.sensor_execution_status:
                try:
                    single_message = GlobalData.leaving_work_zone_queue.get(timeout=1)
                    single_message = single_message[0]
                except queue.Empty:
                    logger.warning("[Leaving_WorkZone] Queue empty - waiting for messages")
                    time.sleep(1)
                    continue

                if not GlobalData.sensor_execution_status:
                    logger.info("[Leaving_WorkZone] sensor_execution_status disabled - exiting loop")
                    break

                try:
                    mexico_time = datetime.now(ZoneInfo("America/Mexico_City")).strftime(TIME_FORMAT)
                    single_message[constant.META_FRAME_METADATA][constant.META_EVENT_MANAGER_CONSUME_TIME] = mexico_time

                    camera_id = single_message[constant.CAMERA_METADATA][constant.META_CAMERA_ID]
                    camera_asset_id = single_message[constant.CAMERA_METADATA][constant.META_CAMERA_ASSET_ID]
                    location_id = single_message[constant.CAMERA_METADATA][constant.META_LOCATION_ID]
                    usecase_name = single_message[constant.META_FRAME_METADATA][constant.META_USECASE_NAME]

                    decode_time = single_message[constant.META_FRAME_METADATA][constant.META_TIMESTAMP]
                    frame_consume_from_event_manager = single_message[constant.META_FRAME_METADATA][constant.META_EVENT_MANAGER_CONSUME_TIME]

                    output_frames = single_message[constant.META_FRAME_METADATA][constant.META_OUTPUT_IMAGE_DATA]

                    if isinstance(output_frames, str):
                        try:
                            output_frames = json.loads(output_frames)
                        except Exception as ex:
                            logger.error(f"[Leaving_WorkZone] Failed to json-load output_frames: {ex}")
                            continue

                    if not isinstance(output_frames, dict):
                        logger.error("[Leaving_WorkZone] Invalid output_frames received (not a dict)")
                        continue

                    camera_list = list(output_frames.keys())
                    if not camera_list:
                        logger.error("[Leaving_WorkZone] output_frames dict is empty")
                        continue

                    num_frames = len(output_frames.get(camera_list[0], []))
                    logger.info(f"[Leaving_WorkZone] Received {len(camera_list)} cameras, frames per camera: {num_frames}")

                    if num_frames == 0:
                        logger.warning("[Leaving_WorkZone] No frames in first camera - skipping message")
                        continue

                    composite_frames = []
                    for i in range(num_frames):
                        ith_raw = []
                        for cam in camera_list:
                            try:
                                ith_raw.append(output_frames[cam][i])
                            except Exception:
                                logger.debug(f"[Leaving_WorkZone] Missing frame index {i} for camera {cam}, inserting placeholder")
                                ith_raw.append(None)

                        # Try composite; if failing, skip this frame index
                        try:
                            # Filter out None frames before sending to composite function
                            frames_for_composite = [f for f in ith_raw if f is not None]
                            if not frames_for_composite:
                                logger.warning(f"[Leaving_WorkZone] All frames for index {i} are None - skipping index")
                                continue

                            final_frame = util.composite_two_row_centered(
                                frames_for_composite, frame_height, frame_width, padding_frames
                            )
                            composite_frames.append(final_frame)
                        except Exception as ex:
                            logger.error(f"[Leaving_WorkZone] composite_two_row_centered failed for index {i}: {ex}")
                            # skip this index and continue processing the rest
                            continue

                    key = f"{camera_asset_id}_{usecase_name}"
                    try:
                        inactivity_threshold = int(util.get_interval_value_for_event(usecase_name))
                    except Exception:
                        inactivity_threshold = 600
                    logger.info(f"[Leaving_WorkZone] inactivity_threshold={inactivity_threshold}")

                    event_lock = get_event_lock(key)
                    # Try to acquire lock with timeout to avoid deadlocks
                    acquired = False
                    try:
                        acquired = event_lock.acquire(timeout=5)
                        if not acquired:
                            logger.error(f"[Leaving_WorkZone] Could not acquire event lock for {key} - skipping this message")
                            continue

                        if not composite_frames:
                            logger.warning(f"[Leaving_WorkZone] No composite frames generated for key={key} - skipping event logic")
                            continue

                        first_frame_time = decode_time
                        last_frame_time = frame_consume_from_event_manager

                        if isinstance(first_frame_time, str):
                            first_frame_time = datetime.strptime(first_frame_time, TIME_FORMAT).replace(
                                tzinfo=ZoneInfo("America/Mexico_City")
                            )
                        if isinstance(last_frame_time, str):
                            # try both possible formats
                            try:
                                last_frame_time = datetime.strptime(last_frame_time, TIME_FORMAT).replace(
                                    tzinfo=ZoneInfo("America/Mexico_City"))
                            except Exception:
                                last_frame_time = datetime.strptime(last_frame_time, DB_TIME_FORMAT).replace(
                                    tzinfo=ZoneInfo("America/Mexico_City"))

                        if last_frame_time < first_frame_time:
                            last_frame_time = first_frame_time + timedelta(seconds=2)
                            logger.info("[Leaving_WorkZone] Corrected time anomaly between first/last frame")

                        last_event = DatabaseManager().GetLastEvent(camera_asset_id, usecase_name)

                        if last_event and last_event.event_end_time:
                            last_event_end_time = last_event.event_end_time
                            if isinstance(last_event_end_time, str):
                                try:
                                    last_event_end_time = datetime.strptime(last_event_end_time, DB_TIME_FORMAT).replace(
                                        tzinfo=ZoneInfo("America/Mexico_City"))
                                except Exception:
                                    last_event_end_time = datetime.strptime(last_event_end_time, TIME_FORMAT).replace(
                                        tzinfo=ZoneInfo("America/Mexico_City"))
                            elif isinstance(last_event_end_time, datetime) and last_event_end_time.tzinfo is None:
                                last_event_end_time = last_event_end_time.replace(tzinfo=ZoneInfo("America/Mexico_City"))

                            gap = (first_frame_time - last_event_end_time).total_seconds()
                            if gap < inactivity_threshold:
                                new_end_time = max(last_event_end_time, last_frame_time)
                                try:
                                    DatabaseManager().UpdateEndEventTimeByEventId(
                                        last_event.event_id,
                                        new_end_time.strftime(TIME_FORMAT)
                                    )
                                    logger.info(f"[EVENT] [{usecase_name}] [{key}] Event {last_event.event_id} extended.")
                                except Exception as ex:
                                    logger.error(f"[Leaving_WorkZone] Failed to update end time for event {last_event.event_id}: {ex}")
                                # continue processing next messages; do not return
                                continue

                        # generate event
                        event_generation = EventGenerationHandler()
                        try:
                            final_event_report, processed_tmp_path, processed_final_path = \
                                event_generation.analyse_event_of_leaving_work_zone(
                                    composite_frames, first_frame_time, last_frame_time,
                                    camera_asset_id, usecase_name
                                )
                        except Exception as ex:
                            logger.error(f"[Leaving_WorkZone] analyse_event_of_leaving_work_zone failed: {ex}")
                            # cleanup any partial files and continue
                            for path in (processed_tmp_path if 'processed_tmp_path' in locals() else None,
                                        processed_final_path if 'processed_final_path' in locals() else None):
                                try:
                                    if path and os.path.exists(path):
                                        os.remove(path)
                                except Exception:
                                    pass
                            continue

                        no_of_frames = len(composite_frames)
                        frames_range = f"{first_frame_time},{last_frame_time}"
                        timestamp_first = first_frame_time
                        timestamp_last = last_frame_time if last_frame_time >= timestamp_first else (timestamp_first + timedelta(seconds=2))
                        request_status = 1
                        usecase_id = int(constant.usecase_dict.get(usecase_name))

                        # persist events
                        for object_name, detection in final_event_report:
                            evidence_video_on_nas = None
                            evidence_url = None

                            if processed_final_path:
                                try:
                                    evidence_video_on_nas, evidence_url = MinioUploader.upload_video(
                                        processed_final_path, "evidence_videos"
                                    )
                                except Exception as ex:
                                    logger.error(f"[Leaving_WorkZone] Failed uploading processed video: {ex}")

                            final_url_for_db = evidence_url

                            if evidence_url is None:
                                logger.info(f"[Leaving_WorkZone] Evidence URL missing for object {object_name} — skipping event.")
                                continue

                            event_data = event_generation.prepare_event_data(
                                camera_id, location_id, camera_asset_id, object_name,
                                detection, decode_time, final_url_for_db,
                                usecase_name, usecase_id, request_status
                            )

                            event_type_id = 2
                            email_notification_status = True

                            try:
                                event_logged, event_id, event_uid = CreateDBEvent._add_event_generator_data(
                                    event_data, no_of_frames, frames_range,
                                    timestamp_first, timestamp_last,
                                    email_notification_status,
                                    constant.SUCCESS_STATUS,
                                    evidence_video_on_nas,
                                    event_type_id,
                                    1
                                )
                            except Exception as ex:
                                logger.error(f"[Leaving_WorkZone] Failed to add event to DB: {ex}")
                                continue

                            # Camera Evidence
                            if len(camera_list) > 1:
                                evidence_list = []
                                try:
                                    for cam_name in camera_list:
                                        try:
                                            cam_frames = output_frames.get(cam_name, [])
                                            # timestamp_first/last are datetimes
                                            ts_str_start = timestamp_first.strftime("%Y%m%d%H%M%S")
                                            ts_str_end = timestamp_last.strftime("%Y%m%d%H%M%S")
                                            
                                            single_video_path = event_generation.create_single_camera_video(
                                                cam_frames, cam_name, ts_str_start, ts_str_end, usecase_name
                                            )
                                            
                                            if single_video_path:
                                                video_on_nas, video_url = MinioUploader.upload_video(
                                                    single_video_path, "evidence_videos"
                                                )
                                                
                                                if video_url:
                                                    evidence_list.append({
                                                        "event_id": event_id,
                                                        "camera_name": cam_name,
                                                        "evidence_url": video_url
                                                    })
                                                else:
                                                    logger.warning(f"[Leaving_WorkZone] Video URL is None for camera {cam_name}")
                                                
                                                # Cleanup local file
                                                if os.path.exists(single_video_path):
                                                    os.remove(single_video_path)
                                                    
                                        except Exception as inner_cam_ex:
                                            logger.error(f"[Leaving_WorkZone] Failed to process individual camera {cam_name}: {inner_cam_ex}")
                                    
                                    if evidence_list:
                                        try:
                                            DatabaseManager().InsertEventEvidences(evidence_list)
                                        except Exception as db_ex:
                                            logger.error(f"[Leaving_WorkZone] Bulk insert failed: {db_ex}", exc_info=True)
                                    else:
                                        logger.warning(f"[Leaving_WorkZone] Evidence list is empty for event {event_id}. Skipping bulk insert.")

                                except Exception as outer_cam_ex:
                                    logger.error(f"[Leaving_WorkZone] Error in individual camera processing block: {outer_cam_ex}")
                            else:
                                logger.info("[Leaving_WorkZone] Single camera detected - skipping individual evidence video creation and table insertion.")

                            event_manager_end_time = datetime.now(ZoneInfo("America/Mexico_City")).strftime(TIME_FORMAT)

                            try:
                                WebSocketEventNotifier.send_event(
                                    event_id, event_data, no_of_frames, frames_range,
                                    timestamp_first.strftime(TIME_FORMAT),
                                    email_notification_status,
                                    constant.SUCCESS_STATUS,
                                    evidence_video_on_nas,
                                    event_manager_end_time,
                                    event_uid
                                )
                            except Exception as ex:
                                logger.error(f"[Leaving_WorkZone] Failed to send websocket event for event {event_id}: {ex}")

                        # cleanup processed files
                        for path in (processed_tmp_path, processed_final_path):
                            try:
                                if path and os.path.exists(path):
                                    os.remove(path)
                            except Exception:
                                pass

                        # continue the main loop (do not return)
                        continue

                    finally:
                        if acquired:
                            try:
                                event_lock.release()
                            except Exception:
                                pass

                except Exception as e:
                    logger.error(f"[Leaving_WorkZone] analyse_leaving_work_zone_msgs Error while processing message: {e}", exc_info=True)
                    # continue processing next message instead of exiting
                    continue

        except Exception as e:
            logger.error(f"[Leaving_WorkZone] analyse_leaving_work_zone_msgs Fatal Error: {e}", exc_info=True)




