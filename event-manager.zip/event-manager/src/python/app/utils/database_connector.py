"""
File : database_manager.py
Description : Handles database connectivity for MySQL using SQLAlchemy.
Created on : 25-Feb-2025
Author : HCLTech
E-mail :
"""

import os
import time
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import SQLAlchemyError
from src.python.app.exceptions.base_exception import DatabaseConnectorException, DatabaseConnectionException
from src.python.app.utils.logger import LoggingConfig
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.constant.global_data import GlobalData
from src.python.app.common.config_manager import cfg


logger = LoggingConfig().setup_logging()


class DatabaseConnector:
    """
    Manages MySQL database connectivity using SQLAlchemy.
    """

    def __init__(self):
        self.db_uri = self._get_db_uri()
        self.db_session = constant.EMPTY_STRING
        self.engine = constant.EMPTY_STRING
        self.conn = constant.EMPTY_STRING
        self.raw_conn = constant.EMPTY_STRING

    def _get_db_uri(self):
        """
        Constructs the database connection URI dynamically.
        """
        DB_USER = cfg.get_environment_config(constant.DB_USER)
        DB_PASSWORD = cfg.get_environment_config(constant.DB_PASSWORD)
        DB_HOST = cfg.get_environment_config(constant.DB_HOST)
        DB_NAME = cfg.get_environment_config(constant.DB_NAME)
        return f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}/{DB_NAME}"

    def create_connection(self, retries=3, delay=5):
        """
        Creates a database connection with retry logic.
        """
        for attempt in range(retries):
            try:
                self.engine = create_engine(self.db_uri, pool_recycle=3600, echo=False)
                self.conn = self.engine.connect()
                logger.debug("Database connection established successfully.")
                return self.conn
            except SQLAlchemyError as e:
                logger.error(f"Database connection failed (attempt {attempt + 1}): {e}")
                if attempt < retries - 1:
                    time.sleep(delay)
                    logger.info("Retrying database connection...")
                else:
                    self.create_connection()
                    raise DatabaseConnectorException("Database connection failed after retries.") from e
                   

    def create_raw_connection(self):
        """
        Creates a raw database connection.
        """
        try:
            self.engine = create_engine(self.db_uri, echo=False)
            self.raw_conn = self.engine.raw_connection()
            logger.info("Raw database connection established successfully.")
        except SQLAlchemyError as e:
            logger.error(f"Failed to create raw connection: {e}")
            raise DatabaseConnectionException("Failed to establish raw connection.") from e

    def create_session(self):
        """
        Creates a database session.
        """
        try:
            Session = sessionmaker(bind=self.engine)
            self.db_session = Session()
            logger.debug("Database session created successfully.")
        except SQLAlchemyError as e:
            logger.error(f"Error in create_session: {e}")
            raise DatabaseConnectorException("Error in create_session.") from e
        
        

    def get_connection(self):
        return self.conn

    def get_raw_connection(self):
        """
        get database connection as per environment.
        """
        return self.raw_conn

    def get_session(self):
        return self.db_session
    
    def delete_connection(self, connection):
        status = constant.FAILURE_STATUS
        try:
            connection.invalidate()
            connection.close()
            self.engine.dispose()
            status = constant.SUCCESS_STATUS
        except Exception as e:
            logger.error("Getting exception in delete_connection - {0}".format(e))
            raise DatabaseConnectorException("Getting exception in delete_connection - {0}".format(e))
        return status

    def delete_session(self, current_session):
        status = constant.FAILURE_STATUS
        try:
            current_session.close()
            status = constant.SUCCESS_STATUS
        except Exception as e:
            logger.error("Getting exception in delete_session - {0}".format(e))
            raise DatabaseConnectorException("Getting exception in delete_session - {0}".format(e))
        return status
