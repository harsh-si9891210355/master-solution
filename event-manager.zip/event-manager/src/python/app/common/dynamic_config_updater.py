from src.python.app.constant.project_constant import Constant as constant
from src.python.app.constant.global_data import GlobalData
from src.python.app.utils.database_manager import DatabaseManager
from src.python.app.utils.logger import LoggingConfig

logger = LoggingConfig().setup_logging()

class DynamicConfigUpdater:
    """
    Load config from DB and update GlobalData fields with correct data types.
    """

    DEFAULT_CONFIGS = {
        constant.EVENT_BATCH_SIZE: 10,
        constant.EVENT_BATCH_AVERAGE_CONFIDENCE: 0.3,
        constant.WALKING_IN_NO_WALK_ZONE_INTERVAL_IN_SECONDS: 15,
        constant.NO_PPE_EVENT_INTERVAL_IN_SECONDS: 15,
        constant.SLEEPING_IN_WORK_ZONE_INTERVAL_IN_SECONDS: 15,
        constant.CELL_PHONE_IN_WORK_ZONE_INTERVAL_IN_SECONDS: 15,
        constant.SPEEDING_INTERVAL_IN_SECONDS: 15,
        constant.GOODS_OBSTRUCTING_ZONE_INTERVAL_IN_SECONDS: 15,
        constant.FACIAL_RECOGNITION_INTERVAL_IN_SECONDS: 15,
        constant.LEAVING_WORK_ZONE_EVENT_INTERVAL_IN_SECONDS : 15,
    }

    FIELD_MAPPING = {
        constant.EVENT_BATCH_SIZE: ("event_batch_size", int),
        constant.EVENT_BATCH_AVERAGE_CONFIDENCE: ("event_batch_average_confidence", float),
        constant.WALKING_IN_NO_WALK_ZONE_INTERVAL_IN_SECONDS: ("walking_in_no_walk_zone_interval_in_seconds", float),
        constant.NO_PPE_EVENT_INTERVAL_IN_SECONDS: ("no_ppe_event_interval_in_seconds", float),
        constant.SLEEPING_IN_WORK_ZONE_INTERVAL_IN_SECONDS: ("sleeping_in_work_zone_interval_in_seconds", float),
        constant.CELL_PHONE_IN_WORK_ZONE_INTERVAL_IN_SECONDS: ("cell_phone_in_work_zone_interval_in_seconds", float),
        constant.SPEEDING_INTERVAL_IN_SECONDS: ("speeding_interval_in_seconds", float),
        constant.GOODS_OBSTRUCTING_ZONE_INTERVAL_IN_SECONDS: ("goods_obstructing_zone_interval_in_seconds", float),
        constant.FACIAL_RECOGNITION_INTERVAL_IN_SECONDS: ("facial_recognition_interval_in_seconds", float),
        constant.LEAVING_WORK_ZONE_EVENT_INTERVAL_IN_SECONDS:("leaving_work_zone_interval_in_seconds", float),
    }

    @classmethod
    def update_global_config(cls):
        try:
            db = DatabaseManager()
            config_rows = db.get_all_configurations()
            config_map = dict(config_rows)
            logger.info(config_rows)

            for key, (global_field, expected_type) in cls.FIELD_MAPPING.items():
                default_value = cls.DEFAULT_CONFIGS.get(key)
                raw_value = config_map.get(key, default_value)

                try:
                    typed_value = expected_type(raw_value)
                    setattr(GlobalData, global_field, typed_value)
                except (ValueError, TypeError):
                    logger.info(f"Invalid type for {key}: {raw_value}, using default: {default_value}")
                    setattr(GlobalData, global_field, default_value)

            logger.info("GlobalData config values updated from DB with type enforcement.")

        except Exception as e:
            logger.error(f"Error updating global config: {e}")
