"""
File : project_constant.py
Description : Constant defined in this class to use across the project
Created on : 17-Feb-2025
Author :  HCLTech
E-mail :
"""

import os

class Constant(object):
    """
    Constant defined in this class to use across the project
    """
    EXECUTION_ENVIRONMENT="EXECUTION_ENVIRONMENT"
    SMTP_PORT='SmtpPort'
    CONFIG_SMTP_SERVER='smtpServer'
    
    #set config default
    CONFIG_DEFAULT = 'DEFAULT'
    CONFIG_DEFAULT_OPERATING_SYSTEM = 'operatingSystem'
    CONFIG_DEFAULT_EXECUTION_ENVIRONMENT = 'executionEnvironment'
    CONFIG_DEFAULT_COMMUNICATION_PROTOCOL = 'CommunicationProtocol'
    
    # Values accepted by ExecutionEnvironment config
    EXECUTION_ENVIRONMENT_LOCAL = 'local'
    EXECUTION_ENVIRONMENT_DEV = 'dev'
    EXECUTION_ENVIRONMENT_PROD = 'prod'
    EXECUTION_ENVIRONMENT_TEST = 'test'
    # EXECUTION_ENVIRONMENT_UAT = 'uat'
    # EXECUTION_ENVIRONMENT_INT = 'int'
    
    
    CONFIG_DEV_ENVIRONMENT = 'DEV_ENVIRONMENT'
    CONFIG_TEST_ENVIRONMENT = 'TEST_ENVIRONMENT'
    CONFIG_LOCAL_ENVIRONMENT = 'LOCAL_ENVIRONMENT'
    CONFIG_PROD_ENVIRONMENT = 'PROD_ENVIRONMENT'
    
    
    PROJECT_ROOT_DIR = os.path.abspath(os.curdir)
    CONFIG_FILE_PATH = 'configuration/config.ini'
    
    CONFIG_RESOURCES = 'RESOURCES'
    CONFIG_RESOURCES_METADATA_TEMPLATE_FILE = 'metadataFilePath'
    CONFIG_RESOURCES_FILTER_METADATA_TEMPLATE_FILE= 'FilterMetadataFilePath'
    CONFIG_RESOURCES_BASE_FILE_SAVE_PATH = 'BaseFileSavePath'
    CONFIG_EVIDENCE_VIDEOS_PATH = "evidenceVideosPath"
    
    
    STOP = 'STOP'
    LAUNCH = 'LAUNCH'
    PAUSE = 'PAUSE'
    RESUME ='RESUME'
    
    CONFIG_WEBSOCKET_URI = "websocketUri"
    CONFIG_WEBSOCKET_HOST = "websocketHost"
    CONFIG_WEBSOCKET_PORT = "websocketPort"
    
    CONFIG_MINIO_SERVER_IP = "minioServerIp"
    CONFIG_MINIO_ACCESS_KEY = "minioAccessKey"
    CONFIG_MINIO_SECRET_KEY = "minioSecretKey"
    CONFIG_MINIO_BUCKET_NAME = "minioBucketName"
    CONFIG_MINIO_ENDPOINT = "minioURL"
    
    CONFIG_RECEIVER_THREAD_COUNT = "receiverThreadCount"
    CONFIG_ANALYSIS_THREAD_COUNT = "analysisThreadCount"
        
    #for log info
    MAX_BYTES = 10000000
    BACKUP_COUNT = 99
    LOGGER_LEVEL = 'INFO'
    LOGGER_FILE_NAME = 'log.txt'
    LOGGER_ROOT_FOLDER_NAME = 'log'
    ALL_PERMISSION = 0o777
    
    CELL_PHONE_WORK_ZONE_USECASE = 'Carrying_Cell_Phone_in_the_Working_Zone'
    DRIVER_AWARENESS_USECASE = 'Driver_Lacking_Awareness_of_People'
    FACIAL_RECOGNITION_USECASE = 'Facial_Recognition'
    GOODS_OBSTRUCTING_ZONE_USECASE = 'Goods_Obstructing_the_Working_Zone'
    LEAVING_WORK_ZONE_USECASE = 'Leaving_the_Working_Zone'
    NO_PPE_USECASE = 'Not_Wearing_Full_PPE'
    SLEEPING_WORK_ZONE_USECASE = 'Sleeping_in_Working_Zone'
    SPEEDING_USECASE = 'Speeding'
    WALKING_NO_WALK_ZONE_USECASE = 'Walking_in_No_Walking_Zone'

    EMPTY_STRING=""
    
    FAILURE_STATUS = False 
    SUCCESS_STATUS = True
    MAX_QUEUE_SIZE = 10000
    
    
    META_FRAME_ID = "frame_id"
    CAMERA_METADATA="camera_metadata"
    META_FRAME_METADATA = "frame_metadata"
    META_IMAGE_DATA = "image_data"
    META_SENSOR_ID = "sensor_id"
    META_TIMESTAMP = "time_stamp"
    META_TO_SKIP = "to_skip"
    META_FRAME_SIZE = "frame_size"
    META_DECODE_TIME_EPOCH = "usecase_time_stamp"
    META_FRAME_RESOLUTION = "frame_resolution"
    META_AI_FRAME_BRIGHT = 'frame_brightness'
    META_AI_FRAME_CONTRAST = 'frame_contrast'
    META_AI_FRAME_BLUR = 'frame_blur'
    META_AI_FRAME_REJECTION_REASON = 'frame_rejection_reason'
    META_AI_PRE_PROC_RECO = "ai_preprocessing_reco"
    META_DETECTED_ITEMS = ""
    META_OUTPUT_IMAGE_DATA = "frame" 
    META_INPUT_IMAGE_DATA= "raw_frame"
    META_INPUT_STREAM_QUALITY = "frame_quality"
    META_CAMERA_ASSET_ID = "name"
    META_LOCATION_NAME = "LOCATION"
    META_LOCATION_ID = "location_id"
    TRASITION_STATE = 'transition'
    META_USECASE_NAME = "usecase_name"
    META_CAMERA_ID = "camera_id"
    META_FRAME_DETECTION = "detection"
    META_FRAME_ALERT = "ALERT"

    META_STREAMHANDLER_SENT_TIME = "rabbitmq_sent_timing"
    META_USECASE_CONSUME_TIME="rabbitmq_consume_timing"
    META_STREAMHANDLER_DECODE_TIME = "time_stamp"
    META_EVENT_MANAGER_CONSUME_TIME = "event_manager_consume_time"
    META_EVENT_MANAGER_SENT_TIME = "event_manager_sent_time"
    
    REASON_BRIGHTNESS = 'brightness'
    REASON_CONTRAST = 'contrast'
    REASON_BLUR = 'blur'
    
    
    WALKING_NO_WALK_ZONE_QUEUE = "intrusion_detection_event_queue"
    DRIVER_AWARENESS_QUEUE = "driver_awareness_event_queue"
    NO_PPE_QUEUE = "ppekit_detection_event_queue"
    SLEEPING_WORK_ZONE_QUEUE = "sleeping_detection_event_queue"
    CELL_PHONE_WORK_ZONE_QUEUE = "cell_phone_work_zone_event_queue"
    SPEEDING_QUEUE = "speeding_event_queue"
    GOODS_OBSTRUCTING_ZONE_QUEUE = "goods_obstructing_zone_event_queue"
    LEAVING_WORK_ZONE_QUEUE = "leaving_work_zone_event_queue"
    FACIAL_RECOGNITION_QUEUE = "face_recognition_event_queue"
    
    RABBITMQ_HOST = "rabbitMqLocalHost"
    RABBITMQ_PORT = "rabbitMqPort"
    RABBITMQ_USERNAME = "rabbitMqUsername"
    RABBITMQ_PASSWORD = "rabbitMqPassword"
    
    DB_USER = "dbUsername"
    DB_PASSWORD = "dbPassword"
    DB_HOST = "dbHost"
    DB_NAME = "dbName"
    
    COMMA=","
    THRESHOLD_FOR_EMAIL_NOTIFICATION="thresholdDaysForEmail"
    
    
    SENSOR_ID = 'sensorId'
    TIMESTAMP = 'sensorStartTime'
    SENSOR_EVENT_TIME = 'eventTime'
    USECASE_ID = 'usecase_id'
    SENSOR_EVENT_TYPE = 'eventType'
    EVIDENCE_STORAGE_PATH = 'evidenceStoragePath'
    REQUEST_STATUS='requestStatus'
    SENSOR_EVENT_CONFIDENCE = 'confidence'
    SENSOR_EVENT_STATUS = 'status'
    SENSOR_EVENT_DATA = 'eventData'
    SENSOR_NOTIFICATION_LEVEL = 'notificationLevel'
    SENSOR_CODE = 'code'
    SENSOR_DESCRIPTION = 'description'
    SENSOR_NOTIFICATION_DATA = 'data'
    SENSOR_EVENT_DATA_ID = 'id'
    SENSOR_EVENT_DATA_VALUE = 'value'
    
    usecase_dict = {
    "Carrying_Cell_Phone_in_the_Working_Zone": 5,
    "Driver_Lacking_Awareness_of_People": 2,
    "Facial_Recognition": 9,
    "Goods_Obstructing_the_Working_Zone": 7,
    "Leaving_the_Working_Zone": 8,
    "Not_Wearing_Full_PPE": 3,
    "Sleeping_in_Working_Zone": 4,
    "Speeding": 6,
    "Walking_in_No_Walking_Zone": 1,
    "Distracted_driving":10,
    "Not_Wearing_Seatbelt":11,
}

    EVENT_TIME = 'eventTime'
    EVENT_TYPE = 'eventType'
    EVENT_DATA = 'eventData'
    
    
    DETECTION_DICT = {
    "Walking_in_No_Walking_Zone": "Person detected walking in a no-walk zone",
    "Driver_Lacking_Awareness_of_People": "Driver showing lack of awareness of nearby people",
    "Not_Wearing_Full_PPE": "Detected not wearing full PPE",
    "Sleeping_in_Working_Zone": "Person sleeping in the working area",
    "Carrying_Cell_Phone_in_the_Working_Zone": "Person using cell phone in work zone",
    "Goods_Obstructing_the_Working_Zone": "Goods obstructing the working zone",
    "Leaving_the_Working_Zone": "No security guard present in the designated work zone",
    "Facial_Recognition": "Person detected via facial recognition",
    "Speeding": "Speeding detected in the work zone",
    "distracted": "Driver detected as distracted in work zone",
    "driver_unbelted" : "Driver detected without seatbelt in work zone"
}
     
    UNKNOWN_MAPPPING={
        "IDrive_Usecase":12,
        "IDrive_Location":32
    }
    
    IDRIVE_CAMERA_ID = 726
    FRAMES_TO_CONSIDER_KEY = "framesToConsiderForEvent"
    ELAPSED_TIME_LIMIT_KEY = "elapseTimeInSeconds"
    MIN_FRAMES_WITHIN_TIME_KEY = "minFramesWithInTime"
    BATCH_AVG_CONFIDENCE = "batchAvgConfidence"
    
    
    # Event interval keys
    WALKING_NO_WALK_ZONE_EVENT_INTERVAL_KEY = "walkingInNoWalkZoneIntervalInSeconds"
    DRIVER_AWARENESS_EVENT_INTERVAL_KEY = "driverAwarenessIntervalInSeconds"
    NO_PPE_EVENT_INTERVAL_KEY = "noPPEEventIntervalInSeconds"
    SLEEPING_WORK_ZONE_EVENT_INTERVAL_KEY = "sleepingInWorkZoneIntervalInSeconds"
    CELL_PHONE_WORK_ZONE_EVENT_INTERVAL_KEY = "cellPhoneInWorkZoneIntervalInSeconds"
    SPEEDING_EVENT_INTERVAL_KEY = "speedingIntervalInSeconds"
    GOODS_OBSTRUCTING_ZONE_EVENT_INTERVAL_KEY = "goodsObstructingZoneIntervalInSeconds"
    LEAVING_WORK_ZONE_EVENT_INTERVAL_KEY = "leavingWorkZoneIntervalInSeconds"
    FACIAL_RECOGNITION_EVENT_INTERVAL_KEY = "facialRecognitionIntervalInSeconds"

    EVENT_BATCH_SIZE = "EVENT_BATCH_SIZE"
    EVENT_BATCH_AVERAGE_CONFIDENCE = "EVENT_BATCH_AVERAGE_CONFIDENCE"
    WALKING_IN_NO_WALK_ZONE_INTERVAL_IN_SECONDS = "WALKING_IN_NO_WALK_ZONE_INTERVAL_IN_SECONDS"
    NO_PPE_EVENT_INTERVAL_IN_SECONDS = "NO_PPE_EVENT_INTERVAL_IN_SECONDS"
    SLEEPING_IN_WORK_ZONE_INTERVAL_IN_SECONDS = "SLEEPING_IN_WORK_ZONE_INTERVAL_IN_SECONDS"
    CELL_PHONE_IN_WORK_ZONE_INTERVAL_IN_SECONDS = "CELL_PHONE_IN_WORK_ZONE_INTERVAL_IN_SECONDS"
    SPEEDING_INTERVAL_IN_SECONDS = "SPEEDING_INTERVAL_IN_SECONDS"
    GOODS_OBSTRUCTING_ZONE_INTERVAL_IN_SECONDS = "GOODS_OBSTRUCTING_ZONE_INTERVAL_IN_SECONDS"
    FACIAL_RECOGNITION_INTERVAL_IN_SECONDS = "FACIAL_RECOGNITION_INTERVAL_IN_SECONDS"
    LEAVING_WORK_ZONE_EVENT_INTERVAL_IN_SECONDS = "LEAVING_WORK_ZONE_EVENT_INTERVAL_IN_SECONDS"
    
    ##idrive_constants
    IDRIVE_TEMP_FOLDER = "idrive_videos"
    FFMPEG_BIN = "ffmpeg"
    OVERWRITE_FLAG = "-y"
    INPUT_FLAG = "-i"
    CODEC_FLAG = "-vcodec"
    VIDEO_CODEC = "libx264"
    PIX_FMT_FLAG = "-pix_fmt"
    PIX_FMT = "yuv420p"

    TOKEN_SCHEME = "bearer"
    INVALID_TOKEN = "Invalid or missing token"
    INVALID_TOKEN_SCHEME = "Authorization header must be Bearer token"

    HEALTH_ENDPOINT = "/health"
    WEBHOOK_ENDPOINT = "/webhook"

    STATUS = "status"
    STATUS_OK = "ok"
    STATUS_IGNORED = "ignored"
    STATUS_SUCCESS = "success"
    MESSAGE = "message"
    VIDEO_QUEUED = "Video queued for processing"

    EVENT_TYPE_KEY = "type"
    EVENT_TYPE_STATUS = "status"
    EVENT_TYPE_EVENT = "event"
    DATA_KEY = "data"
    REVIEWS_KEY = "reviews"
    VIDEO_URL = "video_url"
    REVIEW_KEY = "review_key"
    REVIEW_DATE = "review_date"
    DECODE_EPOCH_TIME = "decode_epoch_time"
    CREATED_DATETIME = "created_date_time"
    CAMERA_ASSET_ID = "camera_asset_id"
    FRAME_ID = "frame_id"
    LOCATION_ID = "location_id"
    OBJECT_NAME = "object_name"
    DEVICE_KEY = "device"
    SERIAL_NUMBER_KEY = "serial_number"
    DEFAULT_CAMERA = "unknown_camera"
    DEFAULT_REVIEW_KEY = "no_key"
    RAW_PREFIX = "raw"
    CAMERA_ID="camera_id"

    CLUSTER = "cluster"
    IDRIVE_EVENT = "i_drive_event"
    UNKNOWN_MAPPPING = {
        "IDrive_Location": 32,
        "IDrive_Usecase": 12
    }
    LOCATION_KEY = "IDrive_Location"
    USECASE_KEY = "IDrive_Usecase"
    REQUEST_STATUS_SUCCESS = 1
    EVENT_TYPE_IDRIVE = 1
    MISSING_DATA = "Missing 'data' in payload"
    MISSING_VIDEO_URL = "Missing video_url in event"
    FAILED_VIDEO_DOWNLOAD = "Failed to download video"
    CONVERSION_FAILED = "Video conversion failed"
    MISSING_EVIDENCE_UPLOAD = "Evidence upload failed"

    LOG_IGNORED_STATUS_EVENT = "Status event received. Ignoring."
    EXCEPTION_WEBHOOK_FAILED = "Webhook processing failed"
    WEBHOOK_FAILED = "Webhook processing failed"

    DATETIME_FORMAT = "%Y%m%d_%H%M%S"
    ISO_TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"

    SERVER_HOST = "0.0.0.0"
    SERVER_PORT = 8001
    LOG_LEVEL = "info"
    UNSUPPORTED_EVENT_TYPE="unsupported_event_time"
    IDRIVE_MINIO_FOLDER="idrive-videos"
    
    
    #MILESTONE CONSTANT
    MILESTONE_SERVER_URL = "mileStoneServerURL"
    MILESTONE_USERNAME = "mileStoneServerUserName"
    MILESTONE_PASSWORD = "mileStonePassword"
    MILESTONE_NOTIFICATION_FLAG = "mileStoneNotificationFlag"
    
    
    #evidence video
    CONFIG_EVIDENCE_VIDEO_WIDTH = "evidenceVideoWidth"
    CONFIG_EVIDENCE_VIDEO_HEIGHT = "evidenceVideoHeight"
    SAVE_SPEED_FRAME_IMAGES_FLAG = "saveSpeedFrameImages"
    PADDING_FOR_CONCATNATION = "paddingSizeForConcat"
    
        
    EVENT_DETECTED_TEMPLATE = """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
            body {{
                font-family: Arial, sans-serif;
                background-color: #f2f4f8;
                color: #333333;
                padding: 20px;
            }}
            .container {{
                background-color: #ffffff;
                padding: 30px;
                border-radius: 12px;
                box-shadow: 0 4px 8px rgba(0,0,0,0.05);
                max-width: 600px;
                margin: auto;
            }}
            .header {{
                text-align: center;
                font-size: 24px;
                font-weight: bold;
                color: #3e64ff;
                margin-bottom: 20px;
            }}
            .message {{
                font-size: 16px;
                line-height: 1.6;
            }}
            .details {{
                background-color: #f9f9f9;
                border: 1px solid #e0e0e0;
                padding: 15px;
                border-radius: 8px;
                margin-top: 20px;
            }}
            .details p {{
                margin: 8px 0;
            }}
            .video-link {{
                margin-top: 20px;
                text-align: center;
            }}
            .video-link a {{
                background-color: #3e64ff;
                color: white;
                padding: 10px 20px;
                border-radius: 5px;
                text-decoration: none;
                font-size: 16px;
            }}
            .footer {{
                font-size: 12px;
                color: #888888;
                margin-top: 30px;
                text-align: center;
            }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">Alert - Event Detected</div>
                <div class="message">
                    Hello {name},<br><br>
                    An event has been detected by the Carrix AI CCTV system. Below are the details:
                </div>
                <div class="details">
                    <p><strong>Device Name:</strong> {device_name}</p>
                    <p><strong>Zone:</strong> {zone}</p>
                    <p><strong>Usecase:</strong> {usecase}</p>
                    <p><strong>Description:</strong> {description}</p>
                    <p><strong>Date:</strong> {date}</p>
                </div>
                <div class="video-link">
                    <a href="{video_url}" target="_blank">View Video</a>
                </div>
                <div class="footer">
                    &copy; {year} Carrix AI CCTV. All rights reserved.
                </div>
            </div>
        </body>
        </html>
        """

    SEND_GRID_EMAIL = "sendGridEmail"
    SEND_GRID_API_KEY = "sendGridApiKey"
    SEND_GRID_EMAIL_FLAG = "sendEmailFlag"
    
    
    IGNORED_REVIEW_KEYS = ['speed', 'hard_cornering', 'None', 'hard_braking', 'super_speed', 'safe_distance_warning', 'covered_camera', "", "none", "Null"]

    FIRST_EVENT_TIME ="first_event_time"
    LAST_EVENT_TIME = "last_event_time"
    EVENT_TOTAL_RUNTIME = "total_runtime"

    ACCEPTANCE_KEYS = ["distracted","driver_unbelted"]



    
  
    
    

    
    
    



