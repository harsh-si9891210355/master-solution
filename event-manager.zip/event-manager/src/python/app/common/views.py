"""
File : views.py
Description : It handles the function corresponding to their routes.
Created on : 05-March-2024
Author :
E-mail :
"""

import time
from flask.views import View
from src.python.app.common.event_processing_handler import SensorProcessingHandler
from src.python.app.constant.global_data import GlobalData
from src.python.app.utils.logger import LoggingConfig
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.common.initiate_queue import InitiateSensor

logger = LoggingConfig().setup_logging()


class LaunchEventManagerView(View):
    """Launch Sensor method to initiate the event manager.
    
    Returns:
        [Object]: Response of launch event manager.
    """

    def dispatch_request(self):
        try:
            event_manager = InitiateSensor()
            while True:
                try:
                    setup_status = event_manager.sensor_setup()
                    if setup_status == constant.SUCCESS_STATUS:
                        break  
                except Exception as e:
                    logger.error(f"Exception in sensor setup: {e}")

                logger.warning("Retrying sensor setup...")
                time.sleep(5)  # Retry after 5 seconds
            GlobalData.sensor_execution_status = constant.SUCCESS_STATUS
            start_sensor_processing = SensorProcessingHandler()

            # Retry thread_status and status until both are True
            while True:
                thread_status = start_sensor_processing._thread_stored_status()
                status = start_sensor_processing.trigger_sensor_processing()

                if thread_status and status:
                    break  

                logger.warning("Retrying sensor processing...")
                time.sleep(5)  # Retry after 5 seconds

        except Exception as e:
            logger.error(f"Exception in launch of Event Manager: {e}")
