"""
File : launch_event_manager.py
Description : Handles launching the event manager by initializing sensor setup and processing.
Created on : 05-March-2024
Author :
E-mail :
"""

import time
import threading
from src.python.app.common.event_processing_handler import EventProcessingHandler
from src.python.app.constant.global_data import GlobalData
from src.python.app.utils.logger import LoggingConfig
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.common.initiate_queue import InitiateSensor

logger = LoggingConfig().setup_logging()


class LaunchEventManager:
    """ 
    Class to launch and manage the event manager workflow including 
            sensor setup and processing.
    """

    def launch_event_manager(self):
        """
        Initiates sensor setup and starts sensor event processing.
        Includes retry logic for setup and processing until successful.
        """
        try:
            event_manager = InitiateSensor()

            while True:
                try:
                    setup_status = event_manager.sensor_setup()
                    if setup_status == constant.SUCCESS_STATUS:
                        break  
                except Exception as e:
                    logger.error(f"Exception in sensor setup: {e}")

                logger.warning("Retrying sensor setup...")
                time.sleep(5)

            GlobalData.sensor_execution_status = constant.SUCCESS_STATUS
            start_sensor_processing = EventProcessingHandler()

            # Retry sensor processing until both thread status and trigger status are True
            while True:
                thread_status = start_sensor_processing._thread_stored_status()
                status = start_sensor_processing.trigger_sensor_processing()

                # monitor_thread = threading.Thread(target=start_sensor_processing.monitor_threads, name="ThreadMonitor", daemon=True)
                # monitor_thread.start()

                if thread_status and status:
                    break  

                logger.warning("Retrying sensor processing...")
                time.sleep(5) 

        except Exception as e:
            logger.error(f"Exception in launching Event Manager: {e}")
