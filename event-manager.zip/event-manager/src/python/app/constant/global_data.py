"""
File : global_data.py
Description : Initializes Global data
Created on : 17-Feb-2025
Author : HCLtech
E-mail :
"""

from src.python.app.constant.project_constant import Constant as constant
import threading

class GlobalData(object):
    """
    Initializes the global data required in all modules of the application
    """
    
    sensor_metadata=None
    receiver_threads=None
    analysis_threads=None

    event_tracking_dict = dict()
    last_event_id_dict={}


    event_lock = threading.Lock()

    
    
    exec_environment_config = None
    sensor_execution_status = None
    sensor_stop_execution_status=False
    stop_request_count_stat=None
    
    
    walking_no_walk_zone_queue = constant.EMPTY_STRING
    driver_awareness_queue = constant.EMPTY_STRING
    no_ppe_queue = constant.EMPTY_STRING
    sleeping_work_zone_queue = constant.EMPTY_STRING
    cell_phone_work_zone_queue = constant.EMPTY_STRING
    distracted_driving_queue = constant.EMPTY_STRING
    speeding_queue = constant.EMPTY_STRING
    no_seatbelt_queue = constant.EMPTY_STRING
    goods_obstructing_zone_queue = constant.EMPTY_STRING
    leaving_work_zone_queue = constant.EMPTY_STRING
    facial_recognition_queue = constant.EMPTY_STRING
    
    
    walk_thread = constant.EMPTY_STRING
    cellphone_thread = constant.EMPTY_STRING
    ppe_thread = constant.EMPTY_STRING
    facial_thread = constant.EMPTY_STRING
    awareness_thread = constant.EMPTY_STRING
    sleep_thread = constant.EMPTY_STRING
    distracted_thread = constant.EMPTY_STRING
    speed_thread = constant.EMPTY_STRING
    seatbelt_thread = constant.EMPTY_STRING
    obstruct_thread = constant.EMPTY_STRING
    leaving_thread = constant.EMPTY_STRING

    walk_analysis_thread = constant.EMPTY_STRING
    cellphone_analysis_thread = constant.EMPTY_STRING
    ppe_analysis_thread = constant.EMPTY_STRING
    facial_analysis_thread = constant.EMPTY_STRING
    awareness_analysis_thread = constant.EMPTY_STRING
    sleep_analysis_thread = constant.EMPTY_STRING
    distracted_analysis_thread = constant.EMPTY_STRING
    speed_analysis_thread = constant.EMPTY_STRING
    seatbelt_analysis_thread = constant.EMPTY_STRING
    obstruct_analysis_thread = constant.EMPTY_STRING
    leaving_analysis_thread = constant.EMPTY_STRING
    
    rabbitmq_connection = None
    rabbitmq_channel=None
     
    db_usecase_name = set()
    is_stat_queue_available = None
    
    minio_client = None
    last_event_time_dict = dict()
    
    
    # Dynamic configuration parameters
    event_batch_size = None
    event_batch_average_confidence = None
    walking_in_no_walk_zone_interval_in_seconds = None
    no_ppe_event_interval_in_seconds = None
    sleeping_in_work_zone_interval_in_seconds = None
    cell_phone_in_work_zone_interval_in_seconds = None
    speeding_interval_in_seconds = None
    goods_obstructing_zone_interval_in_seconds = None
    facial_recognition_interval_in_seconds = None
    leaving_work_zone_interval_in_seconds = None

    