"""
File : initiate_sensor.py
Description : InitiateSensor is responsible for initiating and setting up sensor services.
Created on : 25-March-2025
Author : HCLTech
"""

import logging
import queue
from src.python.app.common.rabbitmq_messaging_service import RabbitMQService
from src.python.app.exceptions.base_exception import (
    SensorInitiationException,
    SchemaValidationException,
    ClusterListEmptyException,
    RabbitMQServiceMessagingServiceManagerException
)
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.constant.global_data import GlobalData
from src.python.app.utils.logger import LoggingConfig

logger = LoggingConfig().setup_logging()


class InitiateSensor:
    """
    InitiateSensor class responsible for setting up and initiating sensor services.
    """

    def __init__(self):
        """
        Constructor for InitiateSensor.
        """
        self.messaging_service_status = constant.FAILURE_STATUS

    def sensor_setup(self):
        """
        Sets up RabbitMQ services and initializes queues for different use cases.

        Raises:
            SensorInitiationException: If an error occurs during setup.
            ClusterListEmptyException: If the use case list is empty.

        Returns:
            bool: True if setup is successful, otherwise False.
        """
        try:
            logging.getLogger("pika").setLevel(logging.WARNING)
            messaging_service = RabbitMQService().connect()
            self.messaging_service_status = messaging_service
        except RabbitMQServiceMessagingServiceManagerException as e:
            logger.error(f"Exception occurred in connection with RabbitMQ: {e}")

        try:
            GlobalData.db_usecase_name = [
                constant.WALKING_NO_WALK_ZONE_USECASE,
                constant.CELL_PHONE_WORK_ZONE_USECASE,
                constant.NO_PPE_USECASE,
                constant.FACIAL_RECOGNITION_USECASE,
                constant.SLEEPING_WORK_ZONE_USECASE,
                constant.SPEEDING_USECASE,
                constant.GOODS_OBSTRUCTING_ZONE_USECASE,
                constant.LEAVING_WORK_ZONE_USECASE
            ]
        except SchemaValidationException as e:
            raise SensorInitiationException(f"Exception occurred in schema validation: {e}") from e

        if not GlobalData.db_usecase_name:
            raise ClusterListEmptyException("Cluster name list is empty, cannot proceed!")

        try:
            for usecase_name in GlobalData.db_usecase_name:
                if usecase_name == constant.WALKING_NO_WALK_ZONE_USECASE:
                    GlobalData.walking_no_walk_zone_queue = queue.Queue(maxsize=constant.MAX_QUEUE_SIZE)
                elif usecase_name == constant.CELL_PHONE_WORK_ZONE_USECASE:
                    GlobalData.cell_phone_work_zone_queue = queue.Queue(maxsize=constant.MAX_QUEUE_SIZE)
                elif usecase_name == constant.NO_PPE_USECASE:
                    GlobalData.no_ppe_queue = queue.Queue(maxsize=constant.MAX_QUEUE_SIZE)
                elif usecase_name == constant.FACIAL_RECOGNITION_USECASE:
                    GlobalData.facial_recognition_queue = queue.Queue(maxsize=constant.MAX_QUEUE_SIZE)
                elif usecase_name == constant.SLEEPING_WORK_ZONE_USECASE:
                    GlobalData.sleeping_work_zone_queue = queue.Queue(maxsize=constant.MAX_QUEUE_SIZE)
                elif usecase_name == constant.SPEEDING_USECASE:
                    GlobalData.speeding_queue = queue.Queue(maxsize=constant.MAX_QUEUE_SIZE)
                elif usecase_name == constant.GOODS_OBSTRUCTING_ZONE_USECASE:
                    GlobalData.goods_obstructing_zone_queue = queue.Queue(maxsize=constant.MAX_QUEUE_SIZE)
                elif usecase_name == constant.LEAVING_WORK_ZONE_USECASE:
                    GlobalData.leaving_work_zone_queue = queue.Queue(maxsize=constant.MAX_QUEUE_SIZE)
                    

                logger.info(f"Queue initialized for usecase: {usecase_name}")

            return self.messaging_service_status

        except SensorInitiationException as e:
            logger.error(f"RabbitMQ Service error during sensor initiation: {e}")
            return constant.FAILURE_STATUS
