#!/bin/sh

# Read version from file, remove the leading 'v'
VERSION=$(cat version.txt | sed 's/^v//')

# Split VERSION into MAJOR, MINOR, PATCH
IFS='.' 
set -- $VERSION
MAJOR=$1
MINOR=$2
PATCH=$3


# Construct new version string
NEW_VERSION="v${MAJOR}.${MINOR}.${PATCH}"

# Save new version to version.txt
echo "$NEW_VERSION" > version.txt

# Save to version.env for GitLab dotenv report
echo "CI_VERSION=$NEW_VERSION" > version.env

# Print result for logs
echo "Bumped version to $NEW_VERSION"