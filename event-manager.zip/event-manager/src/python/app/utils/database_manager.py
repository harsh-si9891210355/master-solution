"""
File : database_manager.py
Description : This handles queries which interacts with database.
Created on : 13-Mar-2025
Author :
E-mail :
"""


from src.python.app.common.config_manager import cfg
from src.python.app.exceptions.base_exception import SchemaValidationException
from src.python.app.utils.utilities import util
from src.python.app.utils.logger import LoggingConfig
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.constant.global_data import GlobalData
from src.python.app.utils.database_connector import DatabaseConnector
from database.models.request_event_info import RequestEventInfo
from database.models.location_info import LocationInfo
from database.models.configuration import Configuration
from database.models.event_evidences import EventEvidences

from sqlalchemy import and_, desc

logger = LoggingConfig().setup_logging()


class DatabaseManager:
    """ 
        Handles database queries as per arguments.
    """

    dbSession = None

    def __init__(self):
        self.db_connector = None
        self.conn = None
        self.dbSession = None
        self.raw_conn = None
        
        
    def GetRequestStateInsertSensorEvent(self, model):
        """ Inserts and update data into table as per arguments.
            Args: 
                model ([Object]): [ Model name with field arguments ]
            Raises:
                None   
            Returns: 
                [] : None
        """
        try:
            self.__get_dbInstance()
            self.dbSession.add(model)
            self.dbSession.commit()
            self.dbSession.refresh(model) 
            return constant.SUCCESS_STATUS, model.event_id , model.unique_event_id

        except Exception as e:
            raise SchemaValidationException("Exception in GetRequestStateInsertSensorEvent : {0}".format(e))
        finally:
            self.__delete_dbInstance()
    
    
    
    def __delete_dbInstance(self):
        '''
        Delete database connection and session
        '''
        try:
            if self.raw_conn:
                self.raw_conn.close()
                self.raw_conn = None
            else:
                self.db_connector.delete_session(self.dbSession)
                self.db_connector.delete_connection(self.conn)
            self.db_connector = None
            self.conn = None
            self.dbSession = None
        except Exception as e:
            logger.error("Getting exception in __delete_dbInstance - {0}".format(e))
            raise SchemaValidationException("Getting exception in __delete_dbInstance - {0}".format(e))
         
    def UpdateEndEventTimeByEventId(self, event_id, event_end_time):
        """
        Updates the end_event_time for a given event_id.

        Args:
            event_id (int): ID of the event to update.
            end_event_time (datetime): New end_event_time value.

        Raises:
            SchemaValidationException: If the update fails or event not found.

        Returns:
            Tuple: (status, updated_model)
        """
        try:
            self.__get_dbInstance()

            event_model = self.dbSession.query(RequestEventInfo).filter_by(event_id=event_id).first()

            if not event_model:
                raise SchemaValidationException(f"No event found with event_id: {event_id}")

            event_model.event_end_time = event_end_time

            self.dbSession.commit()
            self.dbSession.refresh(event_model)

            return constant.SUCCESS_STATUS, event_model

        except Exception as e:
            raise SchemaValidationException(f"Exception in UpdateEndEventTimeByEventId: {e}")
        finally:
            self.__delete_dbInstance()
        
         
    def GetLastEmailEvent(self, camera_asset_id,usecase_id):
        """
        Get the most recent email event for the given camera_asset_id.
        """
        self.__get_dbInstance()
        try:
            last_email_event = self.dbSession.query(RequestEventInfo).filter_by(camera_asset_id=camera_asset_id, usecase_id=usecase_id).order_by(desc(RequestEventInfo.created_date_time)).first()
            return last_email_event
        except Exception as e:
            logger.error("Error retrieving last email event for camera asset ID {}: {}".format(camera_asset_id, e))
            return None
        finally:
            self.__delete_dbInstance()

    def GetLastEvent(self, camera_asset_id, usecase_name):
        """
        Get the most recent event for the given camera_asset_id and usecase_id.
        """
        self.__get_dbInstance()
        try:
            last_event = (
                self.dbSession.query(RequestEventInfo)
                .filter_by(camera_asset_id=camera_asset_id, usecase_id=constant.usecase_dict.get(usecase_name))
                .order_by(desc(RequestEventInfo.event_end_time))
                .first()
            )
            logger.info("Getting last event details to update last event time from db as event occured in within time limit")
            return last_event
        except Exception as e:
            logger.error(f"Error retrieving last event for camera_asset_id={camera_asset_id}, usecase_name={usecase_name}: {e}")
            return None
        finally:
            self.__delete_dbInstance()    
            
    def __get_dbInstance(self):
        '''
        Create database connection and session
        '''
        try:
            self.db_connector = DatabaseConnector()
            self.db_connector.create_connection()
            self.db_connector.create_session()
            self.conn = self.db_connector.get_connection()
            self.dbSession = self.db_connector.get_session()
        except Exception as e:
            logger.error("Getting exception in __get_dbInstance - {0}".format(e))
            raise SchemaValidationException("Getting exception in __get_dbInstance - {0}".format(e))

    
    def __delete_dbInstance(self):
        '''
        Delete database connection and session
        '''
        try:
            if self.raw_conn:
                self.raw_conn.close()
                self.raw_conn = None
            else:
                self.db_connector.delete_session(self.dbSession)
                self.db_connector.delete_connection(self.conn)
            self.db_connector = None
            self.conn = None
            self.dbSession = None
        except Exception as e:
            logger.error("Getting exception in __delete_dbInstance - {0}".format(e))
            raise SchemaValidationException("Getting exception in __delete_dbInstance - {0}".format(e))
        
    def get_all_configurations(self):
        """
        Retrieves all configuration entries as a dictionary with parameter as key and value as value.

        Returns:
            dict: Dictionary of configuration parameters and their corresponding values.
        """
        self.__get_dbInstance()
        try:
            config_rows = self.dbSession.query(Configuration).all()
            config_dict = {row.parameter: row.value for row in config_rows}
            return config_dict
        except Exception as e:
            logger.error("Error retrieving configuration data: {}".format(e))
            raise SchemaValidationException("Error retrieving configuration data: {}".format(e))
        finally:
            self.__delete_dbInstance()
            
    def GetLocationName(self, location_id):
        """
        Get the location name for the given location_id from the database.
        """
        self.__get_dbInstance()
        try:
            location_record = self.dbSession.query(LocationInfo).filter_by(id=location_id).first()
            if location_record:
                return location_record.location  # Use correct attribute name
            else:
                logger.warning(f"No location found for location_id: {location_id}")
                return None
        except Exception as e:
            logger.error("Error retrieving location name for location ID {}: {}".format(location_id, e))
            return None
        finally:
            self.__delete_dbInstance()

    def __get_raw_dbInstance(self):
        '''
        Create database raw connection and session
        '''
        self.db_connector = DatabaseConnector()
        self.db_connector.create_raw_connection()
        self.raw_conn = self.db_connector.get_raw_connection()

    def InsertEventEvidences(self, evidence_list):
        """
        Inserts multiple records into event_evidences table.
        Args:
            evidence_list (list): List of dictionaries containing event_id, camera_name, and evidence_url
        """
        self.__get_dbInstance()
        try:
            evidences = [
                EventEvidences(
                    event_id=item['event_id'],
                    camera_name=item['camera_name'],
                    evidence_url=item['evidence_url']
                ) for item in evidence_list
            ]
            
            self.dbSession.add_all(evidences)
            self.dbSession.commit()
            return constant.SUCCESS_STATUS
        except Exception as e:
            logger.error(f"Error inserting event evidences bulk: {e}")
            raise SchemaValidationException(f"Error inserting event evidences bulk: {e}")
        finally:
            self.__delete_dbInstance()

            
    