"""
Defines the Location model for managing different locations.

Author: HCLTech
"""

from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()

class LocationInfo(Base):
    """
    Represents a location in the system.
    """
    __tablename__ = "location"

    id = Column(Integer, primary_key=True, autoincrement=True)
    location = Column(String(255), nullable=True)

 