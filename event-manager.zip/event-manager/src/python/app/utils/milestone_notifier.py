"""
File: milestone_notifier.py
Description: Sends event and alarm notifications to Milestone with token-based authentication
Created on: 12-06-2025
Author: HCLTech
"""

import json
import requests
import urllib3

from src.python.app.utils.logger import LoggingConfig
from src.python.app.utils.milestone_identity_provider import get_token
from src.python.app.common.config_manager import cfg
from src.python.app.constant.project_constant import Constant

logger = LoggingConfig().setup_logging()


class MilestoneNotifier:
    def __init__(self):
        self.server_url = cfg.get_environment_config(Constant.MILESTONE_SERVER_URL)
        self.username = cfg.get_environment_config(Constant.MILESTONE_USERNAME)
        self.password = cfg.get_environment_config(Constant.MILESTONE_PASSWORD)
        self.is_basic_user = True
        self.verify_ssl = True
        self.session = requests.Session()
        self.access_token = None
        self.headers = {}

        if not self.verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        logger.debug("[MILESTONE] Notifier initialized with server URL: %s", self.server_url)

    def authenticate(self) -> bool:
        try:
            logger.info("[MILESTONE] Authenticating...")
            response = get_token(self.session, self.username, self.password, self.server_url, self.is_basic_user, self.verify_ssl)
            if response.status_code != 200:
                logger.error("[MILESTONE] Authentication failed: %s", response.text)
                return False

            self.access_token = response.json()["access_token"]
            self.headers = {
                "Authorization": f"Bearer {self.access_token}",
                "Content-Type": "application/json",
            }
            logger.debug("[MILESTONE] Access token acquired.")
            return True
        except Exception as e:
            logger.exception("[MILESTONE] Exception during authentication: %s", e)
            return False

    def send_event(self, event_type_id: str):
        try:
            if not self.access_token and not self.authenticate():
                return

            url = f"{self.server_url}/api/rest/v1/events"
            payload = {"type": event_type_id}
            response = self.session.post(url, headers=self.headers, data=json.dumps(payload), verify=self.verify_ssl)

            if response.status_code != 202:
                raise RuntimeError(f"[MILESTONE] Failed to trigger event: {response.text}")

            event = response.json().get("data")
            logger.info(f"[MILESTONE] Event triggered successfully: {event}")
            return event
        except Exception as e:
            logger.error(f"[MILESTONE] Failed to trigger event: {e}")
            raise

    def send_alarm(self, camera_asset_id: str, usecase_name: str, msg: str):
        try:
            if not self.access_token and not self.authenticate():
                return Constant.FAILURE_STATUS

            url = f"{self.server_url}/api/rest/v1/alarms"
            payload = {
                "name": usecase_name,
                "message": msg,
                "source": camera_asset_id,
            }
            response = self.session.post(url, headers=self.headers, data=json.dumps(payload), verify=self.verify_ssl)

            if response.status_code != 202:
                raise RuntimeError(f"[MILESTONE] Failed to send alarm: {response.text}")

            alarm = response.json().get("data")
            logger.info(f"[MILESTONE] Alarm sent successfully for camera {camera_asset_id}")
            return Constant.SUCCESS_STATUS
        except Exception as e:
            logger.error(f"[MILESTONE] Failed to send alarm: {e}")
            return Constant.FAILURE_STATUS

    def get_all_cameras(self):
        try:
            if not self.access_token and not self.authenticate():
                return []

            url = f"{self.server_url}/api/rest/v1/cameras"
            response = self.session.get(url, headers=self.headers, verify=self.verify_ssl)

            if response.status_code != 200:
                raise RuntimeError(f"[MILESTONE] Failed to fetch cameras: {response.text}")

            return response.json().get("array", [])
        except Exception as e:
            logger.error(f"[MILESTONE] Failed to retrieve cameras: {e}")
            raise

    def get_camera_id_by_name(self, camera_name: str) -> str:
        try:
            cameras = self.get_all_cameras()
            for cam in cameras:
                if cam.get("name") == camera_name:
                    logger.info(f"[MILESTONE] Found camera '{camera_name}' with ID: {cam.get('id')}")
                    return cam.get("id")
            logger.warning(f"[MILESTONE] Camera with name '{camera_name}' not found.")
            return None
        except Exception as e:
            logger.error(f"[MILESTONE] Error searching for camera: {e}")
            raise



