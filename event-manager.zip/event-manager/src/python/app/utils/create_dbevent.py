"""
File : create_db_event.py
Description : This manages the profile as per request based on params.
Created on : 16-March-2021
Author : HCLTech
E-mail :
"""

from src.python.app.constant.project_constant import Constant as constant
from src.python.app.exceptions.base_exception import SchemaValidationException
from database.models.request_event_info import RequestEventInfo
from src.python.app.utils.database_manager import DatabaseManager
from src.python.app.constant.global_data import GlobalData
from src.python.app.utils.logger import LoggingConfig



logger = LoggingConfig().setup_logging()

from datetime import datetime, timezone
from zoneinfo import ZoneInfo

class CreateDBEvent:

    @staticmethod
    def _add_event_generator_data(event_genarated_data, no_of_frames_in_ei, frames_range, timestamp_first_frame_in_ei,timestamp_last_frame_in_ei, email_sent_status,notification_on_milestone_status,evidence_video_on_nas ,event_type,event_stream_quality):

        """AI is creating summary for _add_event_generator_data
        Raises:
            SchemaValidationException: [description]
        """
        try:
            camera_id = event_genarated_data.get(constant.CAMERA_ID)
            camera_asset_id = event_genarated_data.get(constant.CAMERA_ASSET_ID)
            event_time = event_genarated_data.get(constant.EVENT_TIME)
            usecase_id = event_genarated_data.get(constant.USECASE_ID)
            event_data = event_genarated_data.get(constant.EVENT_DATA)
            location_id = event_genarated_data.get(constant.META_LOCATION_ID)
            evidence_storage_path = event_genarated_data.get(constant.EVIDENCE_STORAGE_PATH)
            is_evidence_sent_on_nas=evidence_video_on_nas
            notification_on_milestone_status=notification_on_milestone_status
            number_of_frames = no_of_frames_in_ei
            frames_range = frames_range

            if isinstance(timestamp_first_frame_in_ei, str):
                created_date_time = datetime.strptime(timestamp_first_frame_in_ei, "%Y-%m-%dT%H:%M:%S.%f")
            elif isinstance(timestamp_first_frame_in_ei, datetime):
                created_date_time = timestamp_first_frame_in_ei
            else:
                raise ValueError("Invalid type for timestamp_first_frame_in_ei")

            if isinstance(timestamp_last_frame_in_ei, str):
                timestamp_last_frame_in_ei = timestamp_last_frame_in_ei.replace(" ", "T")
                last_frame_time = datetime.strptime(timestamp_last_frame_in_ei, "%Y-%m-%dT%H:%M:%S.%f")
            elif isinstance(timestamp_last_frame_in_ei, datetime):
                last_frame_time = timestamp_last_frame_in_ei
            else:
                raise ValueError("Invalid type for timestamp_last_frame_in_ei")
            event_end_time = last_frame_time     
            
            is_email_sent = email_sent_status
            request_status = event_genarated_data.get(constant.REQUEST_STATUS)
            event_type = event_type
            # Call to insert data.
            event_generator = RequestEventInfo(camera_id, camera_asset_id ,location_id,str(event_time), usecase_id, str(event_data), evidence_storage_path,
                                number_of_frames, frames_range, created_date_time, last_frame_time, is_email_sent,is_evidence_sent_on_nas,notification_on_milestone_status,request_status,event_type,event_end_time,event_stream_quality)
            status, event_id, event_uid = DatabaseManager().GetRequestStateInsertSensorEvent(event_generator)
                                
            return status, event_id, event_uid
        except Exception as e:
            raise SchemaValidationException("_add_event_generator_data --> Exception occurred in datatabase opertion: {0}".format(e)) from e
