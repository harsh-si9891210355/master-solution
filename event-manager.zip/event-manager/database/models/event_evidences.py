
from sqlalchemy import Column, String, Integer, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from database.models.request_event_info import Base
import datetime

class EventEvidences(Base):
    """
    Model for event_evidences table
    """
    __tablename__ = 'event_evidences'

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey('events.event_id'), nullable=False)
    camera_name = Column(String(255), nullable=False)
    evidence_url = Column(String(500), nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    # Relationship to RequestEventInfo (events table)
    event = relationship("RequestEventInfo", backref="evidences")

    def __init__(self, event_id, camera_name, evidence_url):
        self.event_id = event_id
        self.camera_name = camera_name
        self.evidence_url = evidence_url
