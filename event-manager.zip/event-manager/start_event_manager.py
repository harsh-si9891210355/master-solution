"""
File        : start_event_manager.py
Description : Entry point to launch the Event Manager application, initializing key components like 
              environment config, webhook server, WebSocket server, and Minio uploader.
Created on  : 05-March-2025
Author      : HCLTech
"""

import os
import traceback
import time
from src.python.app.constant.project_constant import Constant as constant
from src.python.app.common.config_manager import cfg
from src.python.app.utils.logger import LoggingConfig
from src.python.app.constant.global_data import GlobalData
from src.python.app.common.setup_event_manager import LaunchEventManager
from src.python.app.utils.web_socket_event_notifier import WebSocketEventNotifier
from src.python.app.utils.minio_video_uploader import MinioUploader
from src.python.app.utils.webhook_handler import start_webhook_server
from src.python.app.common.dynamic_config_updater import DynamicConfigUpdater
from src.python.app.utils.config_alert_consumer import start_config_updater_ws_server

logger = LoggingConfig().setup_logging()


def set_execution_environment():
    """
    Sets the execution environment in GlobalData based on environment variable.
    """
    execution_env = os.getenv(constant.EXECUTION_ENVIRONMENT, None)

    if not execution_env:
        logger.error("Missing environment variable: %s", constant.EXECUTION_ENVIRONMENT)
        return

    execution_env_lower = execution_env.lower()
    if execution_env_lower == constant.EXECUTION_ENVIRONMENT_LOCAL:
        GlobalData.exec_environment_config = constant.CONFIG_LOCAL_ENVIRONMENT
    elif execution_env_lower == constant.EXECUTION_ENVIRONMENT_DEV:
        GlobalData.exec_environment_config = constant.CONFIG_DEV_ENVIRONMENT
    elif execution_env_lower == constant.EXECUTION_ENVIRONMENT_TEST:
        GlobalData.exec_environment_config = constant.CONFIG_TEST_ENVIRONMENT
    elif execution_env_lower == constant.EXECUTION_ENVIRONMENT_PROD:
        GlobalData.exec_environment_config = constant.CONFIG_PROD_ENVIRONMENT
    else:
        logger.error("Invalid environment value '%s'. Expected one of: local, dev, test, prod", execution_env)
        return

    logger.info("Execution environment is set to: %s", GlobalData.exec_environment_config)


if __name__ == '__main__':
    try:
        set_execution_environment()

        if GlobalData.exec_environment_config is None:
            logger.critical(
                "Execution Environment not set. Please set one of: local, dev, test, prod "
                "in the environment variable '%s'.", constant.EXECUTION_ENVIRONMENT
            )
        
        DynamicConfigUpdater.update_global_config()
        logger.info("All config values updated from DB")
        
        start_config_updater_ws_server()
        logger.info("To change global config websocket server thread started in background")
        
        start_webhook_server()
        logger.info("Webhook API thread started")

        WebSocketEventNotifier.start_websocket_server()
        logger.info("WebSocket server started")

        video_uploader = MinioUploader()
        logger.info("Minio uploader initialized")

        logger.info("Event Manager Pipeline starting ---")
        launchObject = LaunchEventManager()
        launchObject.launch_event_manager()

    except Exception as e:
        logger.error("Exception occurred during Event Manager startup: %s", str(e))
        logger.debug("Stack trace:\n%s", traceback.format_exc())
