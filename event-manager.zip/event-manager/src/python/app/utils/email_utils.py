"""
Provides utility functions for sending email for various in-app operations.
Author: HCLTech
"""
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from datetime import datetime
from src.python.app.constant.project_constant import Constant
from src.python.app.utils.logger import LoggingConfig
from src.python.app.common.config_manager import cfg 

logger = LoggingConfig().setup_logging()

class EmailService:
    def __init__(self):
        
        self.sender_email = cfg.get_environment_config(Constant.SEND_GRID_EMAIL)
        self.client = SendGridAPIClient(api_key = str(cfg.get_environment_config(Constant.SEND_GRID_API_KEY)))
        
    def send_email(self, to_email: str, subject: str, plain_text: str, html_content: str):
        """
        Sends an email using SendGrid.
        Args:
            to_email (str): Recipient's email address.
            subject (str): Subject of the email.
            plain_text (str): Plain text content.
            html_content (str): HTML content.
        Returns:
            bool: True if the email was sent successfully (status code 202), False otherwise.
        """
        message = Mail(
            from_email=self.sender_email,
            to_emails=to_email,
            subject=subject,
            plain_text_content=plain_text,
            html_content=html_content
        )
        try:
            response = self.client.send(message)
            return response.status_code == 202
        except Exception as e:
            logger.error(f"Error sending email to {to_email}: {e}")
            return False