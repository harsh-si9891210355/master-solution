
# Event Manager

## Overview

The **Event Manager** is a Python-based application that handles event generation, processing, and queue management using RabbitMQ. It also supports metadata management, shared storage operations, and database interactions.

## Directory Structure

```
├── configuration
│   └── config.ini                     # Main configuration file
├── requirements.txt                  # Python dependencies
├── resources
│   └── metadata.json                 # Stream metadata information
├── src
│   └── python
│       └── app
│           ├── common                  
│           │   ├── config_manager.py             
│           │   ├── event_generation_handler.py  
│           │   ├── event_processing_handler.py  
│           │   ├── initiate_queue.py            
│           │   ├── nas_operation.py             
│           │   ├── rabbitmq_messaging_service.py  
│           │   ├── stream_metadata_handler.py  
│           │   ├── stream_processor.py          
│           │   └── views.py                      
│           ├── constant                
│           │   ├── global_data.py                
│           │   └── project_constant.py           
│           ├── exceptions              
│           │   └── base_exception.py             
│           └── utils                   
│               ├── database_connector.py        
│               ├── database_manager.py          
│               ├── email_utils.py               
│               ├── image_conversion.py          
│               ├── logger.py                    
│               └── utilities.py                 
├── start_event_manager.py            # Entry point to start the event manager
```

## Features

* **Event Generation & Processing**: Handles event creation and processing via RabbitMQ.
* **Queue Management**: Initiates and manages message queues.
* **Metadata Handling**: Processes and stores stream metadata.
* **Storage Operations**: Supports file operations on Minio storage.
* **Database Integration**: Manages database connections and queries.
* **Logging & Utilities**: Includes logging, email notifications, and image conversion utilities.

## Setup & Installation

### 1. Clone the repository

```sh
git clone https://gitlab.com/carrix-ai/carrix_eventmanager
cd carrix_eventmanager
```

### 2. Install dependencies

```sh
pip install -r requirements.txt
```

### 3. Configure settings

Edit the `configuration/config.ini` file with environment-specific values:

```ini
[DEFAULT]
executionEnvironment = local  # Options: local, dev, prod, test

# RabbitMQ Configuration
rabbitMqLocalHost = rabbitmq
rabbitMqPort = 5672
rabbitMqUsername = user
rabbitMqPassword = password

# Database Configuration(change host and port as per vm configuration)
dbUsername = db_user
dbPassword = carrix_ILz
dbHost = carrix_mysql
dbName = carrix_db
dbPort = 3306

# WebSocket Configuration(change host and port as per vm configuration if local mention 0.0.0.0 and port 9004)
websocketUri = ws://0.0.0.0:9004
websocketPort = 9004
websocketHost = 0.0.0.0

# Email & Alerts
thresholdHoursForEmail = 1
smtpPort = 9005
smtpServer = 0.0.0.0

# MinIO Object Storage(change host and port as per vm configuration if local mention 0.0.0.0 and port 9000)
minioServerIp = http://0.0.0.0:9000
minioAccessKey = admin
minioSecretKey = 1tQC870x
minioBucketName = carrix-bucket
minioURL = http://0.0.0.0:9000
```

Update `resources/metadata.json` with metadata required for processing.

### 4. Start the Event Manager

```sh
python start_event_manager.py
```

## Testing

To validate the setup and functionality, run:

```sh
python start_event_manager.py
```

## Supported Environments

* `local`: For local development and testing
* `dev`: For internal testing environments
* `prod`: For production deployment
* `test`: For Test deployment

The behavior and connectivity change depending on the selected `executionEnvironment` in `config.ini`.

## Contributing

* Follow standard Python coding practices.
* Ensure proper logging and exception handling.
* Submit pull requests (PRs) for improvements and new features.

---

## .env file changes
* Change token to change token and keep that token in this file

## Architecture Diagram

![Event Manager Architecture](resources/event_manager_architecture.png)

